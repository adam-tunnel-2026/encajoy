#!/bin/sh
# Install only the isolated Encajoy service. No VPN, DNS, firewall or proxy changes.
set -eu
if [ "$(id -u)" != 0 ]; then
  echo 'Ejecuta este instalador con sudo desde la consola de tu servidor.' >&2
  exit 1
fi
command -v python3 >/dev/null
command -v systemctl >/dev/null
encajoy_source_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if ! systemctl is-active --quiet encajoy-community && command -v ss >/dev/null && ss -ltn '( sport = :8787 )' | tail -n +2 | grep -q .; then
  echo 'El puerto local 8787 está ocupado. No se ha modificado ningún servicio.' >&2
  exit 1
fi
install -d -m 755 /opt/encajoy-community
install -m 644 "$encajoy_source_dir/server.py" /opt/encajoy-community/server.py
if [ ! -f /etc/encajoy-community.env ]; then
  (umask 077; python3 - <<'PY'
import secrets
from pathlib import Path
Path('/etc/encajoy-community.env').write_text('ENCAJOY_SECRET='+secrets.token_hex(32)+'\nENCAJOY_DB=/var/lib/encajoy-community/towns.sqlite3\nENCAJOY_PORT=8787\nPYTHONDONTWRITEBYTECODE=1\n')
PY
  )
fi
install -m 644 "$encajoy_source_dir/encajoy-community.service" /etc/systemd/system/encajoy-community.service
systemctl daemon-reload
systemctl enable --now encajoy-community
systemctl restart encajoy-community
python3 - <<'PY'
import time
import urllib.request
for attempt in range(10):
    try:
        print(urllib.request.urlopen('http://127.0.0.1:8787/health',timeout=2).read().decode())
        break
    except OSError:
        if attempt==9:raise
        time.sleep(.5)
PY
echo 'Servicio local instalado. Falta conectar la ruta HTTPS del dominio y configurar esa URL en la APK.'
