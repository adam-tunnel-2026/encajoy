#!/usr/bin/env python3
"""Encajoy community service. Python standard library only; use an HTTPS reverse proxy."""
import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import sqlite3
import threading
import time
import unicodedata
from collections import defaultdict, deque
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SHAPES = [
    [(x, y) for y, row in enumerate(pattern.split('/')) for x, v in enumerate(row) if v == '1']
    for pattern in ['1','11','1/1','111','1/1/1','11/11','10/11','01/11','111/010',
                    '111/100','110/011','1111','1/1/1/1','111/111','111/111/111']
]
EASY = [0,0,1,1,2,2,3,4,5,6,7]
ROUND_MS = 180000


def replay(seed, moves):
    if type(seed) is not int or not 0 <= seed < 2**32:
        raise ValueError('Semilla no válida.')
    if not isinstance(moves, list) or not 1 <= len(moves) <= 2000:
        raise ValueError('La ronda no contiene jugadas válidas.')
    board, score, combo, last = [None]*64, 0, 0, -1

    def random():
        nonlocal seed
        seed = (seed*1664525+1013904223) & 0xffffffff
        return seed/4294967296

    def refill():
        return [(EASY[int(random()*len(EASY))], int(random()*5)) for _ in range(3)]

    def fits(piece, col, row):
        return all(0 <= col+x < 8 and 0 <= row+y < 8 and board[(row+y)*8+col+x] is None
                   for x, y in SHAPES[piece[0]])

    tray = refill()
    for move in moves:
        if not isinstance(move, list) or len(move) != 3 or any(type(v) is not int for v in move):
            raise ValueError('Jugada no válida.')
        slot, index, elapsed = move
        if not (0 <= slot < 3 and 0 <= index < 64 and 0 <= elapsed < ROUND_MS and last <= elapsed):
            raise ValueError('Jugada fuera de tiempo o tablero.')
        piece = tray[slot]
        if piece is None or not fits(piece, index % 8, index//8):
            raise ValueError('La pieza no cabe.')
        if last >= 0 and not any(p and any(fits(p, i%8, i//8) for i in range(64)) for p in tray):
            raise ValueError('La ronda ya había terminado.')
        last = elapsed
        for x, y in SHAPES[piece[0]]:
            board[(index//8+y)*8+index%8+x] = piece[1]
        cleared, lines = set(), 0
        for i in range(8):
            for horizontal in (True, False):
                cells = [i*8+j if horizontal else j*8+i for j in range(8)]
                if all(board[c] is not None for c in cells):
                    lines += 1
                    cleared.update(cells)
        for cell in cleared:
            board[cell] = None
        combo = combo+1 if lines else 0
        score += len(SHAPES[piece[0]]) + lines*25*(lines+combo-1)
        tray[slot] = None
        if not any(tray):
            tray = refill()
        # A board with no possible move ends early and is not a three-minute completion.
        if not any(p and any(fits(p, i%8, i//8) for i in range(64)) for p in tray):
            raise ValueError('Esta ronda terminó sin espacio antes de los 3 minutos.')
    return score


def city_name(value):
    if not isinstance(value, str):
        raise ValueError('Nombre de pueblo no válido.')
    city = ' '.join(unicodedata.normalize('NFC', value).split())
    if not 2 <= len(city) <= 40 or not any(c.isalpha() for c in city):
        raise ValueError('Escribe un pueblo o ciudad de 2 a 40 letras.')
    if any(not (unicodedata.category(c)[0] in 'LM' or c in " .’'-") for c in city):
        raise ValueError('Escribe solo el nombre de un pueblo o ciudad.')
    return city


class Community:
    def __init__(self, database, secret, clock=time.time):
        if len(secret) < 32:
            raise ValueError('ENCAJOY_SECRET debe contener al menos 32 caracteres.')
        self.database, self.secret, self.clock = database, secret.encode(), clock
        self.lock = threading.Lock()
        self.limits = defaultdict(deque)
        with closing(self.connect()) as db, db:
            db.execute("PRAGMA journal_mode=WAL").fetchone()
            db.execute('CREATE TABLE IF NOT EXISTS towns (id TEXT PRIMARY KEY, city TEXT NOT NULL, score INTEGER NOT NULL, expires INTEGER NOT NULL)')
            db.execute('CREATE INDEX IF NOT EXISTS towns_expiry ON towns(expires)')

    def connect(self):
        return sqlite3.connect(self.database, timeout=10)

    def allowed(self, key, maximum, period):
        now = self.clock()
        with self.lock:
            # Remove stale limiter keys, so idle clients don't accumulate indefinitely.
            if len(self.limits) > 1000:
                for old in list(self.limits):
                    if not self.limits[old] or self.limits[old][-1] < now-3600:
                        del self.limits[old]
            hits = self.limits[key]
            while hits and hits[0] <= now-period:
                hits.popleft()
            if len(hits) >= maximum:
                return False
            hits.append(now)
            return True

    def start(self, body):
        seed = body.get('seed')
        if body.get('rules') != 'easy-v1' or type(seed) is not int or not 0 <= seed < 2**32:
            raise ValueError('Actualiza Encajoy para participar con estas reglas.')
        payload = {'id': secrets.token_hex(16), 'seed': seed, 'issued': int(self.clock()*1000), 'rules':'easy-v1'}
        data = base64.urlsafe_b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode().rstrip('=')
        signature = hmac.new(self.secret, data.encode(), hashlib.sha256).hexdigest()
        return {'token':data+'.'+signature, 'seed':seed}

    def verify(self, token):
        if not isinstance(token, str) or len(token) > 1000:
            raise ValueError('Ronda no válida.')
        try:
            data, signature = token.split('.')
            expected = hmac.new(self.secret, data.encode(), hashlib.sha256).hexdigest()
            if not hmac.compare_digest(signature, expected):
                raise ValueError()
            payload = json.loads(base64.urlsafe_b64decode(data+'='*(-len(data)%4)))
            elapsed = int(self.clock()*1000)-payload['issued']
            if payload['rules'] != 'easy-v1' or not ROUND_MS <= elapsed <= 900000:
                raise ValueError()
            return payload
        except (ValueError, KeyError, TypeError):
            raise ValueError('Completa los 3 minutos y publica antes de 15 minutos desde el inicio.') from None

    def publish(self, body):
        payload = self.verify(body.get('token'))
        city = city_name(body.get('city'))
        score = replay(payload['seed'], body.get('moves'))
        now = int(self.clock()*1000)
        with closing(self.connect()) as db, db:
            # An HTTP retry never restarts the one-hour lifetime or duplicates the entry.
            db.execute('INSERT OR IGNORE INTO towns VALUES (?, ?, ?, ?)', (payload['id'],city,score,now+3600000))
            row = db.execute('SELECT id,city,score,expires FROM towns WHERE id=?', (payload['id'],)).fetchone()
        return {'id':row[0], 'city':row[1], 'score':row[2], 'expiresAt':row[3]}

    def towns(self):
        now = int(self.clock()*1000)
        with closing(self.connect()) as db:
            rows = db.execute('SELECT id,city,score,expires FROM towns WHERE expires > ? ORDER BY expires,id', (now,)).fetchall()
        return {'now':now, 'towns':[{'id':r[0],'city':r[1],'score':r[2],'expiresAt':r[3]} for r in rows]}


    def purge_expired(self):
        now = int(self.clock()*1000)
        with closing(self.connect()) as db, db:
            db.execute('DELETE FROM towns WHERE expires <= ?', (now,))


def handler_for(community):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'Encajoy'

        def log_message(self, *_):
            pass  # No IP, city or token logs.

        def send_json(self, status, body):
            raw = json.dumps(body, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.send_header('Access-Control-Allow-Origin', 'https://encajoy.invalid')
            self.send_header('Vary', 'Origin')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers()
            self.wfile.write(raw)

        def do_OPTIONS(self):
            self.send_response(204)
            self.send_header('Access-Control-Allow-Origin','https://encajoy.invalid')
            self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers','Content-Type')
            self.end_headers()

        def client_key(self):
            # The service binds only to loopback; the reverse proxy overwrites this header.
            return self.headers.get('X-Real-IP',self.client_address[0])

        def do_GET(self):
            if self.path == '/health':
                return self.send_json(200, {'ok':True,'rules':'easy-v1'})
            if self.path != '/towns':
                return self.send_json(404, {'error':'Ruta no encontrada.'})
            if not community.allowed(('get',self.client_key()),120,60):
                return self.send_json(429, {'error':'Espera un momento y vuelve a intentarlo.'})
            try:
                result = community.towns()
            except sqlite3.Error as error:
                logging.error('Encajoy GET /towns: %s', getattr(error, 'sqlite_errorname', type(error).__name__))
                return self.send_json(503, {'error':'Servicio ocupado. Vuelve a intentarlo.'})
            self.send_json(200, result)

        def do_POST(self):
            if self.path not in ('/rounds','/towns'):
                return self.send_json(404, {'error':'Ruta no encontrada.'})
            if not community.allowed((self.path,self.client_key()),30 if self.path=='/rounds' else 15,60):
                return self.send_json(429, {'error':'Espera un momento y vuelve a intentarlo.'})
            try:
                size = int(self.headers.get('Content-Length','0'))
                if not 0 < size <= 100000:
                    return self.send_json(413, {'error':'Petición demasiado grande o vacía.'})
                self.connection.settimeout(10)
                body = json.loads(self.rfile.read(size))
                if not isinstance(body, dict):
                    raise ValueError('Petición no válida.')
                result = community.start(body) if self.path == '/rounds' else community.publish(body)
                self.send_json(200, result)
            except (ValueError, TypeError, UnicodeError):
                self.send_json(400, {'error':'No se ha podido validar la ronda o el pueblo. Completa los 3 minutos y publica antes de 15 minutos desde el inicio.'})
            except (OSError, sqlite3.Error) as error:
                logging.error('Encajoy POST %s: %s', self.path, getattr(error, 'sqlite_errorname', type(error).__name__))
                self.send_json(503, {'error':'Servicio ocupado. Vuelve a intentarlo.'})
    return Handler


if __name__ == '__main__':
    community = Community(os.environ.get('ENCAJOY_DB','towns.sqlite3'),os.environ.get('ENCAJOY_SECRET',''))
    service = ThreadingHTTPServer(('127.0.0.1',int(os.environ.get('ENCAJOY_PORT','8787'))),handler_for(community))
    def cleanup():
        while True:
            time.sleep(60)
            try:
                community.purge_expired()
            except sqlite3.Error as error:
                logging.error('Encajoy cleanup: %s', getattr(error, 'sqlite_errorname', type(error).__name__))
    threading.Thread(target=cleanup,daemon=True).start()
    service.serve_forever()
