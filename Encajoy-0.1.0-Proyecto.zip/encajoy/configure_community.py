#!/usr/bin/env python3
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit
url=sys.argv[1].rstrip('/') if len(sys.argv)==2 else ''
parsed=urlsplit(url)
if url and (parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment):
    sys.exit('Usa una URL HTTPS de tu servidor, sin usuario, contraseña, consulta ni fragmento.')
if '<' in url or '>' in url or any(c.isspace() for c in url):
    sys.exit('URL no válida.')
(Path(__file__).resolve().parent/'app/src/main/assets/community-config.json').write_text(json.dumps({'url':url})+'\n')
print('Comunidad configurada.' if url else 'Comunidad desactivada. El juego sigue funcionando sin conexión.')
