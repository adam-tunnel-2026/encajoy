package es.encajoy.game;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.widget.TextView;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONObject;

/** Bundled game; network access is restricted to the configured community service. */
public final class MainActivity extends Activity {
    private WebView game;
    private Uri community;
    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer,0,count);
            return out.toString("UTF-8");
        }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        game = new WebView(this);
        game.setBackgroundColor(0xff101827);
        game.getSettings().setJavaScriptEnabled(true);
        game.getSettings().setDomStorageEnabled(true);
        game.getSettings().setAllowFileAccess(false);
        game.getSettings().setAllowContentAccess(false);
        game.getSettings().setMediaPlaybackRequiresUserGesture(true);
        game.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        try {
            String url = new JSONObject(readAsset("community-config.json")).optString("url", "").replaceAll("/+$", "");
            Uri candidate = Uri.parse(url);
            if ("https".equals(candidate.getScheme()) && candidate.getHost() != null && candidate.getUserInfo() == null
                    && candidate.getQuery() == null && candidate.getFragment() == null) community = candidate;
        } catch (Exception ignored) { community = null; }
        game.setWebChromeClient(new WebChromeClient());
        game.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (community != null && "https".equals(uri.getScheme()) && community.getHost().equals(uri.getHost())
                        && community.getPort() == uri.getPort() && uri.getQuery() == null) {
                    String base = community.getPath() == null ? "" : community.getPath();
                    String path = uri.getPath();
                    if ((base + "/towns").equals(path) || (base + "/rounds").equals(path)) return null;
                }
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
        });
        setContentView(game);
        try {
            String url = community == null ? "" : community.toString();
            String html = readAsset("index.html").replace("<script>", "<script>window.ENCAJOY_COMMUNITY_URL=" + JSONObject.quote(url).replace("<", "\\u003c") + ";\n");
            game.loadDataWithBaseURL("https://encajoy.invalid/", html, "text/html", "UTF-8", null);
        } catch (Exception error) {
            TextView text = new TextView(this); text.setText("No se ha podido abrir Encajoy. Vuelve a iniciar el juego."); setContentView(text);
        }
    }
    @Override protected void onPause() { if(game!=null)game.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if(game!=null)game.onResume(); }
    @Override protected void onDestroy(){if(game!=null){game.destroy();game=null;}super.onDestroy();}
}
