package es.encajoy.game;

import android.app.Activity;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;
import org.json.JSONObject;

/** SDK-managed advertising choices; never infer consent from game preferences. */
public final class PrivacyController {
    private final Activity activity;
    private final WebView web;
    private ConsentInformation information;
    private boolean requested;
    private boolean error;
    PrivacyController(Activity activity, WebView web) { this.activity=activity; this.web=web; }
    private boolean alive(){ return !activity.isFinishing() && !activity.isDestroyed(); }
    @JavascriptInterface public void ready(){activity.runOnUiThread(this::request);}
    @JavascriptInterface public void status(){activity.runOnUiThread(this::dispatch);}
    @JavascriptInterface public void options(){activity.runOnUiThread(()->{
        if(!alive())return;
        if(information==null || information.getPrivacyOptionsRequirementStatus()!=ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED){dispatch();return;}
        UserMessagingPlatform.showPrivacyOptionsForm(activity, formError->{error=formError!=null;dispatch();});
    });}
    private void request(){
        if(!alive())return;
        if(!BuildConfig.CONSENT_CONFIGURED){dispatch();return;}
        if(requested){dispatch();return;}
        requested=true;
        information=UserMessagingPlatform.getConsentInformation(activity);
        information.requestConsentInfoUpdate(activity,new ConsentRequestParameters.Builder().build(),()->{
            if(!alive())return;
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity,formError->{
                error=formError!=null;dispatch();
            });
        },requestError->{error=true;dispatch();});
    }
    boolean canRequestAds(){return BuildConfig.CONSENT_CONFIGURED && information!=null && information.canRequestAds();}
    private void dispatch(){
        if(!alive())return;
        try{
            JSONObject data=new JSONObject();
            data.put("configured",BuildConfig.CONSENT_CONFIGURED);
            data.put("canRequestAds",canRequestAds());
            data.put("optionsRequired",information!=null && information.getPrivacyOptionsRequirementStatus()==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED);
            data.put("error",error);
            web.evaluateJavascript("if(window.onPrivacyStatus)window.onPrivacyStatus("+data.toString()+");",null);
        }catch(Exception ignored){}
    }
}
