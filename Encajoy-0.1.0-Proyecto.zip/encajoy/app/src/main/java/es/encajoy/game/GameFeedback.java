package es.encajoy.game;

import android.app.Activity;
import android.os.Build;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.webkit.JavascriptInterface;

/** Short feedback for a real line clear, respecting Android's haptic preferences. */
public final class GameFeedback {
    private final Activity activity;
    private final View view;
    private long last;
    GameFeedback(Activity activity, View view){this.activity=activity;this.view=view;}
    @JavascriptInterface public void line(){
        activity.runOnUiThread(()->{
            if(activity.isFinishing()||activity.isDestroyed())return;
            long now=SystemClock.uptimeMillis();if(now-last<200)return;last=now;
            view.performHapticFeedback(Build.VERSION.SDK_INT>=30?HapticFeedbackConstants.CONFIRM:HapticFeedbackConstants.KEYBOARD_TAP);
        });
    }
}
