package es.encajoy.game;

import android.app.Activity;
import android.os.Build;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.webkit.JavascriptInterface;

/** Uses Android's haptic settings for valid moves and line clears. */
public final class GameFeedback {
    private final Activity activity;
    private final View view;

    GameFeedback(Activity activity, View view) {
        this.activity = activity;
        this.view = view;
    }

    @JavascriptInterface public void placement() {
        perform(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    @JavascriptInterface public void line() {
        perform(Build.VERSION.SDK_INT >= 30
                ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.LONG_PRESS);
    }

    private void perform(int effect) {
        activity.runOnUiThread(() -> {
            if (!activity.isFinishing() && !activity.isDestroyed()) {
                view.performHapticFeedback(effect);
            }
        });
    }
}
