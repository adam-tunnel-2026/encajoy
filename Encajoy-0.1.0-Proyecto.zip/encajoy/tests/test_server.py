import json
import pathlib
import sys
import tempfile
import unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'server'))
from server import Community, city_name, replay

class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory()
        self.now=1800000000
        self.service=Community(str(pathlib.Path(self.directory.name)/'test.db'),'test-key-'*8,lambda:self.now)
        self.seed=12345
        self.moves=[[0,0,0]]
        self.token=self.service.start({'seed':self.seed,'rules':'easy-v1'})['token']
    def tearDown(self):
        self.directory.cleanup()
    def test_round_must_complete_and_signature_must_match(self):
        with self.assertRaises(ValueError):self.service.publish({'token':self.token,'city':'Azpeitia','moves':self.moves})
        self.now+=180
        with self.assertRaises(ValueError):self.service.publish({'token':self.token[:-1]+'x','city':'Azpeitia','moves':self.moves})
        result=self.service.publish({'token':self.token,'city':'Azpeitia','moves':self.moves,'score':999999})
        self.assertLess(result['score'],999999)
    def test_expiry_is_individual_and_retry_does_not_extend(self):
        self.now+=180
        first=self.service.publish({'token':self.token,'city':'Azpeitia','moves':self.moves})
        self.now+=5
        again=self.service.publish({'token':self.token,'city':'Bilbao','moves':self.moves})
        self.assertEqual(first,again)
        next_token=self.service.start({'seed':self.seed,'rules':'easy-v1'})['token']
        self.now+=180
        second=self.service.publish({'token':next_token,'city':'Oujda','moves':self.moves})
        self.now=first['expiresAt']/1000
        self.assertEqual([x['city'] for x in self.service.towns()['towns']],['Oujda'])
        self.now=second['expiresAt']/1000
        self.assertEqual(self.service.towns()['towns'],[])
        with self.service.connect() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM towns').fetchone()[0],0)
    def test_expired_sessions_cannot_republish(self):
        self.now+=901
        with self.assertRaises(ValueError):self.service.publish({'token':self.token,'city':'Azpeitia','moves':self.moves})
    def test_city_validation(self):
        for name in ['Azpeitia','Donostia / San Sebastián','Oujda','L’Hospitalet']:
            if '/' not in name:self.assertEqual(city_name(name),name)
        for invalid in ['<script>alert(1)</script>','1234','x','https://example.com','a'*41]:
            with self.assertRaises(ValueError):city_name(invalid)
    def test_reject_invalid_moves(self):
        for moves in [[],[[3,0,0]],[[0,64,0]],[[0,0,180000]],[[0,0,0],[0,0,1]],[[0,0,-1]]]:
            with self.assertRaises(ValueError):replay(self.seed,moves)
    def test_more_than_50_entries_can_rotate(self):
        tokens=[self.service.start({'seed':self.seed,'rules':'easy-v1'})['token'] for _ in range(60)]
        self.now+=180
        for token in tokens:self.service.publish({'token':token,'city':'Azpeitia','moves':self.moves})
        self.assertEqual(len(self.service.towns()['towns']),60)
    def test_limiter(self):
        self.assertTrue(self.service.allowed('test',1,60))
        self.assertFalse(self.service.allowed('test',1,60))
        self.now+=60
        self.assertTrue(self.service.allowed('test',1,60))
    def test_js_replay_matches_backend(self):
        path=pathlib.Path('/tmp/encajoy-replay.json')
        if not path.exists():self.skipTest('Run node tests/game.test.cjs first')
        fixture=json.loads(path.read_text())
        self.assertEqual(replay(fixture['seed'],fixture['moves']),fixture['score'])

if __name__=='__main__':unittest.main()
