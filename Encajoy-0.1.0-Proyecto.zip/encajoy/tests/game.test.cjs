const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
class Element{
 constructor(){this.children=[];this.style={setProperty(){}};this.dataset={};this.classes=new Set();this.classList={add:n=>this.classes.add(n),remove:n=>this.classes.delete(n),contains:n=>this.classes.has(n)};this.hidden=false;this.open=false;this.value='';this.textContent='';this.attrs={};}
 addEventListener(name,callback){(this.listeners??={})[name]=callback;}
 append(...items){this.children.push(...items)}
 replaceChildren(...items){this.children=[...items]}
 setAttribute(k,v){this.attrs[k]=v}
 getBoundingClientRect(){return {left:0,top:0,width:40,height:40}}
 querySelectorAll(){return []}
 showModal(){this.open=true}
 close(){this.open=false}
 remove(){}
 animate(){const animation={};(this.animations??=[]).push(animation);return animation;}
}
let now=1800000000000,networkFail=false,requests=[];
const RealDate=Date;
class Clock extends RealDate{constructor(...a){super(...(a.length?a:[now]))}static now(){return now}}
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()]));
const storage=new Map();
const context=vm.createContext({console,Date:Clock,Math,Set,Array,Number,String,JSON,Promise,Error,Boolean,
 document:{getElementById:id=>elements[id],createElement:()=>new Element(),createElementNS:()=>new Element(),body:new Element(),addEventListener(){}},
 localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
 window:{ENCAJOY_COMMUNITY_URL:'https://example.test/encajoy'},
 navigator:{},matchMedia:()=>({matches:true}),confirm:()=>true,prompt(){},
 setInterval(){},clearInterval(){},setTimeout(){return 0},clearTimeout(){},AbortController,
 fetch:async(url,options)=>{requests.push({url,options});if(networkFail)throw new Error('offline');return {ok:true,json:async()=>url.endsWith('/rounds')?{token:'test-token'}:options?.method==='POST'?{expiresAt:now+3600000}:{now,towns:[]}}}
});
vm.runInContext(html.match(/<script>([\s\S]*)<\/script>/)[1],context);
const run=s=>vm.runInContext(s,context);
(async()=>{
 await Promise.resolve();
 assert.equal(requests.length,0,'no community request before the optional choice');
 assert.equal(elements.privacy.open,true,'first-run privacy notice');
 elements['community-choice'].checked=true;run("$('privacy-continue').onclick()");
 assert.equal(run('communityEnabled'),true);
 assert.equal(elements.clock.hidden,true,'classic has no visible timer');run("openMode('daily')");assert.equal(elements.clock.hidden,true);
 run("openMode('timed',true)");assert.equal(elements.clock.hidden,false);
 run('setVolume(1000)');assert.equal(run('volume'),1);run('setVolume(-10)');assert.equal(run('volume'),0);
 run('setVolume(60)');run("$('quieter').onclick()");assert.equal(run('volume'),.5);run("$('louder').onclick()");assert.equal(run('volume'),.6);
 assert.equal(JSON.parse(storage.get('orbita-bloques-v1-volume')),.6);
 for(let i=0;i<1000;i++){run('refill()');assert.equal(run('state.tray.every(p=>p.shape<=7)'),true)}
 run("openMode('timed',true,12345)");
 assert.equal(run('state.deadline'),0);
 await run('place(0,0)');
 assert.equal(requests.filter(r=>r.url.endsWith('/rounds')).length,1);
 assert.equal(run('state.moves.length'),1);assert.equal(run('state.deadline'),now+180000);
 now+=180000;run('syncClock()');
 assert.equal(run('state.over'),true);assert.equal(elements.result.open,true);assert.equal(elements['city-form'].hidden,false);
 assert.equal(elements['result-title'].textContent,'¡Ronda completada!');
 elements.city.value='Azpeitia';await run("$('publish').onclick()");assert.equal(run('state.published'),true);
 const publication=requests.find(r=>r.url.endsWith('/towns')&&r.options?.method==='POST');
 assert.equal(JSON.parse(publication.options.body).city,'Azpeitia');
 const count=requests.length;elements.city.value='<script>';await run("$('publish').onclick()");assert.equal(requests.length,count);
 run('towns=Array.from({length:50},(_,i)=>({id:String(i),city:"Pueblo "+i,score:i,expiresAt:Date.now()+3600000}));townCursor=0;rotateTown(false)');
 for(let i=1;i<=50;i++){run('rotateTown()');assert.equal(elements['town-name'].textContent,'Pueblo '+(i%50))}
 // Exercise real curved transitions, including interruption by a refresh or another navigation.
 const frames=[];context.requestAnimationFrame=callback=>frames.push(callback);context.matchMedia=()=>({matches:false});
 run('rotateTown()');assert.equal(frames.length,1);
 frames.shift()(0);frames.shift()(300);
 for(const card of elements['town-ring'].children)assert.equal(/NaN|Infinity/.test(card.children[0].attrs.d),false);
 frames.shift()(600);assert.equal(frames.length,0,'one turn ends without a permanent animation loop');
 run('rotateTown();rotateTown(false)');frames.shift()(0);assert.equal(frames.length,0,'refresh cancels the pending transition');
 run('townCursor=0;rotateTown(false)');context.matchMedia=()=>({matches:true});
 // Carousel navigation pauses automatic rotation and keeps full central names as text.
 run("$('town-prev').onclick()");assert.equal(elements['town-name'].textContent,'Pueblo 49');assert.equal(run('townPaused'),true);
 run("$('town-next').onclick()");assert.equal(elements['town-name'].textContent,'Pueblo 0');
 run("$('town-toggle').onclick()");assert.equal(run('townPaused'),false);
 run('towns=[{id:"only",city:"Azkoitia",score:659,expiresAt:Date.now()+3600000}];townCursor=0;rotateTown(false)');
 assert.equal(elements['town-name'].textContent,'Azkoitia');assert.equal(elements['town-next'].disabled,true);assert.equal(elements['town-ring'].children.length,8);
 run('rotateTown()');assert.equal(elements['town-name'].textContent,'Azkoitia','one genuine result remains readable');
 run('towns[0].city="Villanueva de la Cañada <b>";rotateTown(false)');assert.equal(elements['town-name'].textContent,'Villanueva de la Cañada <b>','towns are text, never HTML');
 now+=3600000;run('rotateTown()');assert.equal(run('towns.length'),0,'entries expire at one hour');
 run('towns=[{id:"a",city:"Azpeitia",score:50,expiresAt:Date.now()+1000},{id:"b",city:"Oujda",score:60,expiresAt:Date.now()+9000}];townCursor=0');now+=1000;run('rotateTown(false)');assert.equal(elements['town-name'].textContent,'Oujda','individual expiry');
 networkFail=true;run("openMode('timed',true,5)");await run('place(0,0)');assert.equal(run('state.moves.length'),1);assert.equal(run('Boolean(state.session)'),false,'offline playable without a fake shared result');
 now+=180000;run('syncClock()');assert.equal(elements['city-form'].hidden,true);
 networkFail=false;run("openMode('timed',true,5)");await run('place(0,0)');run('state.over=true;state.finishedAt=Date.now();finishTimed(false)');assert.equal(elements['city-form'].hidden,true,'early failure cannot publish');
 run("openMode('classic')");assert.equal(elements.clock.hidden,true);
 // Generate a legal multi-line run for independent Python replay parity checks.
 run("openMode('timed',true,2468);state.onlineAttempted=true");
 for(let i=0;i<120;i++){
   const move=run('(()=>{for(let s=0;s<3;s++)if(state.tray[s])for(let n=0;n<64;n++)if(fits(state.tray[s],n%8,Math.floor(n/8)))return [s,n];return null})()');
   if(!move)break;await run(`place(${move[0]},${move[1]})`);now+=100;
 }
 fs.writeFileSync('/tmp/encajoy-replay.json',run('JSON.stringify({seed:state.initialSeed,moves:state.moves,score:state.score,over:state.over})'));
 // Full-shape touch alignment, invalid drops and replay-safe scoring.
 const geo=run('dragGeometry({shape:5,color:0},137.5,260,true,{left:10,top:20},40,43)');
 assert.equal(geo.index,26);assert.equal(geo.left,96);assert.equal(geo.top,149);
 assert.equal(run('dragGeometry({shape:5,color:0},-100,-100,true,{left:10,top:20},40,43).index'),-1);
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=[{shape:5,color:0},null,null]");
 await run('place(0,63)');assert.equal(run('state.score'),0,'invalid drop does not consume or score');assert.equal(run('Boolean(state.tray[0])'),true);
 // Elapsed clocks only progress during active play and freeze behind privacy.
 run('state.started=true;clockTickAt=Date.now()');now+=1000;run('syncClock()');assert.equal(elements['clock-value'].textContent,'0:01');
 run('showPrivacy()');now+=1000;run('syncClock()');assert.equal(elements['clock-value'].textContent,'0:01');
 elements['community-choice'].checked=false;run("$('privacy-continue').onclick()");
 const beforeOffline=requests.length;await run('refreshTowns()');assert.equal(requests.length,beforeOffline,'opt-out stops shared board requests');
 run('window.onPrivacyStatus({configured:true,optionsRequired:true,error:false})');assert.equal(elements['advertising-options'].hidden,false);
 run('window.onPrivacyStatus({configured:false,optionsRequired:false,error:false})');assert.equal(elements['advertising-options'].hidden,true);
 run('state.board=Array.from({length:64},(_,i)=>(Math.floor(i/8)+i%8)%2?1:null);state.tray=[{shape:0,color:0},{shape:5,color:1},{shape:5,color:2}];state.over=false');
 await run('place(0,0)');assert.equal(elements.result.open,true);assert.equal(elements['city-form'].hidden,true);assert.equal(run('state.over'),true);
 run("$('play-again').onclick()");assert.equal(elements.result.open,false);assert.equal(run('state.score'),0);assert.equal(run('state.over'),false);
 assert.equal(JSON.parse(storage.get('orbita-bloques-v1-community-enabled')),false);
 // Restart uses a game dialog, preserving the round if cancelled.
 run("openMode('classic',true);state.score=12;confirm=()=>{throw Error('Native confirm must not run')}");
 run("$('settings-open').onclick()");assert.equal(elements.settings.open,true);
 run("$('restart').onclick()");assert.equal(elements.settings.open,false);assert.equal(elements['restart-dialog'].open,true);assert.equal(run('state.score'),12);
 run("$('restart-cancel').onclick()");assert.equal(elements['restart-dialog'].open,false);assert.equal(run('state.score'),12);
 run("$('restart').onclick();$('restart-confirm').onclick()");assert.equal(run('state.score'),0);assert.equal(elements['restart-dialog'].open,false);
 // Opening settings stops the elapsed counter; switching mode closes settings.
 run('state.started=true;clockTickAt=Date.now()');run("$('settings-open').onclick()");now+=1000;run('syncClock()');assert.equal(run('state.playedMs||0'),0);
 run("$('daily').onclick()");assert.equal(run('mode'),'daily');assert.equal(elements.settings.open,false);assert.equal(elements['mode-name'].textContent,'Reto diario');
 assert.equal(elements.board.children.length,64,'feedback overlay must not become a board cell');
 // A calm classic round can generate the large shapes visible in the reference.
 run("openMode('classic',true);state.score=100;state.seed=123;state.intro=false;seenClassic=new Set()");
 for(let i=0;i<300;i++)run('refill();state.tray.forEach(p=>seenClassic.add(p.shape))');
 for(const shape of [14,15,16,17])assert.equal(run(`seenClassic.has(${shape})`),true,'large classic piece '+shape);
 assert.equal(run('state.tray.every(p=>Boolean(shapes[p.shape]))'),true);
 now+=3600000;run('syncClock()');assert.equal(run('state.over'),false,'classic is never ended by elapsed time');assert.equal(elements.clock.hidden,true);
 // Clear a row and column together, preserving an unrelated occupied cell.
 run("openMode('classic',true);state.intro=false;state.score=100;state.board.fill(null);state.board[0]=3;for(let i=0;i<8;i++){if(i!==4)state.board[24+i]=1;if(i!==3)state.board[i*8+4]=2;}state.tray=[{shape:0,color:0},{shape:1,color:1},{shape:2,color:2}]");
 await run('place(0,28)');assert.equal(run('state.lines'),2);assert.equal(run('state.board.filter(c=>c!==null).length'),1);assert.equal(run('state.board[0]'),3);assert.equal(run('state.score'),201);
 // Classic combo permits two intervening placements; a third miss breaks it.
 run("openMode('classic',true);state.intro=false;state.score=100;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('state.combo'),1);
 await run('place(1,0)');await run('place(2,1)');assert.equal(run('state.combo'),1);
 run('state.tray[0]={shape:0,color:0};for(let i=0;i<7;i++)state.board[i]=0');await run('place(0,7)');assert.equal(run('state.combo'),2);
 run('state.tray=Array.from({length:3},()=>({shape:0,color:0}))');await run('place(0,0)');await run('place(1,1)');await run('place(2,2)');assert.equal(run('state.combo'),0);
 // Timed play retains server-compatible easy-v1 and immediate combo reset.
 run("openMode('timed',true,123);state.onlineAttempted=true;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('state.combo'),1);await run('place(1,0)');assert.equal(run('state.combo'),0);assert.equal(run('state.rules'),'easy-v1');
 let pulses=0;context.window.EncajoyEffects={line(){pulses++}};run('vibration=true;celebrate([[0,0]])');assert.equal(pulses,1);run('vibration=false;celebrate([[0,0]])');assert.equal(pulses,1);
 // Regression: inspecting the final board always leaves two visible escape routes.
 for(const m of ['classic','daily','timed']){
   run(`openMode('${m}',true);state.over=true;state.score=172;render()`);
   run(m==='timed'?'finishTimed(false)':'finishLocal()');assert.equal(elements.result.open,true);
   run("$('close-result').onclick()");assert.equal(elements.result.open,false);assert.equal(elements['end-actions'].hidden,false);assert.equal(elements.status.hidden,true);
   run("$('board-result').onclick()");assert.equal(elements.result.open,true);
   elements.result.listeners.cancel({preventDefault(){}});assert.equal(elements.result.open,false);assert.equal(elements['end-actions'].hidden,false);
   run('save(key(),state)');run(`openMode('${m}')`);assert.equal(elements['end-actions'].hidden,false,'resumed finished round still has restart');
   run("$('board-again').onclick()");assert.equal(run('state.over'),false);assert.equal(run('state.score'),0);assert.equal(elements['end-actions'].hidden,true);assert.equal(elements.status.hidden,false);
 }
 // Exercise the actual animation branch, not only reduced-motion early returns.
 context.matchMedia=()=>({matches:false});run('visualEffects=true;syncEffects();setupAmbientStars()');
 assert.equal(elements['ambient-stars'].children.length,10);
 run("openMode('classic',true);state.intro=false;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('celebrationActive'),true);assert.equal(elements['perfect-effect'].hidden,false);assert.equal(context.document.body.classList.contains('celebrating'),true);
 assert.equal(elements.board.children.length,64);assert.equal(elements['clear-effects'].children.length,9,'eight lit tiles plus one line beam');
 assert.equal(run('state.score'),26,'celebration must not invent bonus points');
 run("openMode('classic',true)");assert.equal(run('celebrationActive'),false);assert.equal(elements['perfect-effect'].hidden,true);assert.equal(context.document.body.classList.contains('celebrating'),false);
 elements['visual-effects'].checked=false;run("$('visual-effects').onchange();perfectCelebration()");assert.equal(run('celebrationActive'),false);assert.equal(context.document.body.classList.contains('effects-off'),true);
 elements['visual-effects'].checked=true;run("$('visual-effects').onchange()");context.matchMedia=()=>({matches:true});run('perfectCelebration()');assert.equal(run('celebrationActive'),false,'OS reduction preference wins');
 console.log('PASS: volume, easy pieces, timer modes, 3-min finish, city publishing, offline fallback, 50-name circular rotation, interrupted animation, manual pause and single-town display, independent expiry, raised drag, invalid drops, elapsed clocks, privacy opt-out, instant restart, classic large pieces, calm play, row/column clears, combo grace and haptic preference, final-board navigation, resumed game-over, visual-effect cleanup and OS motion preference');
})().catch(e=>{console.error(e);process.exit(1)});
