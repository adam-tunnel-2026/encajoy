const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
class Element{
 constructor(){this.children=[];this.style={setProperty(){}};this.dataset={};this.classList={add(){},remove(){}};this.hidden=false;this.open=false;this.value='';this.textContent='';this.attrs={};}
 append(...items){this.children.push(...items)}
 replaceChildren(...items){this.children=[...items]}
 setAttribute(k,v){this.attrs[k]=v}
 getBoundingClientRect(){return {left:0,top:0,width:40,height:40}}
 querySelectorAll(){return []}
 showModal(){this.open=true}
 close(){this.open=false}
 remove(){}
 animate(){return {}}
}
let now=1800000000000,networkFail=false,requests=[];
const RealDate=Date;
class Clock extends RealDate{constructor(...a){super(...(a.length?a:[now]))}static now(){return now}}
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()]));
const storage=new Map();
const context=vm.createContext({console,Date:Clock,Math,Set,Array,Number,String,JSON,Promise,Error,Boolean,
 document:{getElementById:id=>elements[id],createElement:()=>new Element(),body:new Element(),addEventListener(){}},
 localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
 window:{ENCAJOY_COMMUNITY_URL:'https://example.test/encajoy'},
 navigator:{},matchMedia:()=>({matches:true}),confirm:()=>true,prompt(){},
 setInterval(){},clearInterval(){},setTimeout(){return 0},clearTimeout(){},AbortController,
 fetch:async(url,options)=>{requests.push({url,options});if(networkFail)throw new Error('offline');return {ok:true,json:async()=>url.endsWith('/rounds')?{token:'test-token'}:options?.method==='POST'?{expiresAt:now+3600000}:{now,towns:[]}}}
});
vm.runInContext(html.match(/<script>([\s\S]*)<\/script>/)[1],context);
const run=s=>vm.runInContext(s,context);
(async()=>{
 await Promise.resolve();
 assert.equal(elements.clock.hidden,true,'classic timer hidden');run("openMode('daily')");assert.equal(elements.clock.hidden,true);
 run("openMode('timed',true)");assert.equal(elements.clock.hidden,false);
 run('setVolume(1000)');assert.equal(run('volume'),1);run('setVolume(-10)');assert.equal(run('volume'),0);
 run('setVolume(60)');run("$('quieter').onclick()");assert.equal(run('volume'),.5);run("$('louder').onclick()");assert.equal(run('volume'),.6);
 assert.equal(JSON.parse(storage.get('orbita-bloques-v1-volume')),.6);
 for(let i=0;i<1000;i++){run('refill()');assert.equal(run('state.tray.every(p=>p.shape<=7)'),true)}
 run("openMode('timed',true,12345)");
 assert.equal(run('state.deadline'),0);
 await run('place(0,0)');
 assert.equal(requests.filter(r=>r.url.endsWith('/rounds')).length,1);
 assert.equal(run('state.moves.length'),1);assert.equal(run('state.deadline'),now+180000);
 now+=180000;run('syncClock()');
 assert.equal(run('state.over'),true);assert.equal(elements.result.open,true);assert.equal(elements['city-form'].hidden,false);
 assert.equal(elements['result-title'].textContent,'¡Ronda completada!');
 elements.city.value='Azpeitia';await run("$('publish').onclick()");assert.equal(run('state.published'),true);
 const publication=requests.find(r=>r.url.endsWith('/towns')&&r.options?.method==='POST');
 assert.equal(JSON.parse(publication.options.body).city,'Azpeitia');
 const count=requests.length;elements.city.value='<script>';await run("$('publish').onclick()");assert.equal(requests.length,count);
 run('towns=Array.from({length:50},(_,i)=>({id:String(i),city:"Pueblo "+i,score:i,expiresAt:Date.now()+3600000}));townCursor=0;rotateTown(false)');
 for(let i=1;i<=50;i++){run('rotateTown()');assert.equal(elements['town-name'].textContent,'Pueblo '+(i%50))}
 now+=3600000;run('rotateTown()');assert.equal(run('towns.length'),0,'entries expire at one hour');
 run('towns=[{id:"a",city:"Azpeitia",score:50,expiresAt:Date.now()+1000},{id:"b",city:"Oujda",score:60,expiresAt:Date.now()+9000}];townCursor=0');now+=1000;run('rotateTown(false)');assert.equal(elements['town-name'].textContent,'Oujda','individual expiry');
 networkFail=true;run("openMode('timed',true,5)");await run('place(0,0)');assert.equal(run('state.moves.length'),1);assert.equal(run('Boolean(state.session)'),false,'offline playable without a fake shared result');
 now+=180000;run('syncClock()');assert.equal(elements['city-form'].hidden,true);
 networkFail=false;run("openMode('timed',true,5)");await run('place(0,0)');run('state.over=true;state.finishedAt=Date.now();finishTimed(false)');assert.equal(elements['city-form'].hidden,true,'early failure cannot publish');
 run("openMode('classic')");assert.equal(elements.clock.hidden,true);
 // Generate a legal multi-line run for independent Python replay parity checks.
 run("openMode('timed',true,2468);state.onlineAttempted=true");
 for(let i=0;i<120;i++){
   const move=run('(()=>{for(let s=0;s<3;s++)if(state.tray[s])for(let n=0;n<64;n++)if(fits(state.tray[s],n%8,Math.floor(n/8)))return [s,n];return null})()');
   if(!move)break;await run(`place(${move[0]},${move[1]})`);now+=100;
 }
 fs.writeFileSync('/tmp/encajoy-replay.json',run('JSON.stringify({seed:state.initialSeed,moves:state.moves,score:state.score,over:state.over})'));
 console.log('PASS: volume, easy pieces, timer modes, 3-min finish, city publishing, offline fallback, 50-name rotation, independent expiry');
})().catch(e=>{console.error(e);process.exit(1)});
