# Encajoy 0.5.4 — revisión del vídeo y panel del líder

Se ha revisado el vídeo de referencia de 160 segundos, incluido el tramo 36–43 s donde la figura se arrastra y las columnas completas se iluminan antes de soltar.

- Los tambores vectoriales se sitúan dentro de la tarjeta del líder, uno a cada lado del nombre y la puntuación. La caja del texto se ajusta al ancho real de la cara curva, con espacio reservado para cada tambor de 30×30 px. Los nombres largos se acortan visualmente con puntos suspensivos; el texto completo sigue en el documento y la clasificación.
- Los petardos se mantienen en una franja inferior, separados de los nombres y los controles. Se retira el espacio adicional usado por los tambores de la versión anterior.
- En Clásico se dibuja un tono uniforme por tema: rosa en Calma, verde en Bosque y melocotón en Atardecer. Se conservan los índices de color almacenados y las reglas, puntuación y generador de piezas. Contra pueblos conserva su paleta variada.
- El bisel de los bloques se define con caras claras y oscuras más marcadas. La vista previa de filas/columnas tiene un contorno más luminoso y un degradado distinto según orientación. Siguen vigentes la recogida desde debajo de cada pieza y su ampliación inmediata a escala de casilla.

Validación: pruebas Node de juego, gestos, predicción, tono de Clásico, colores de Contra pueblos y encaje geométrico de los tambores, más ocho pruebas Python de servidor aprobadas. Se revisó un dibujo vectorial del componente inferior; no equivale a una captura de Android ni a una validación completa del CSS. El intento de abrir Chromium falló porque el entorno bloquea socket() de process_singleton_posix.cc. No se ha compilado ni probado la APK en un dispositivo. Versión 0.5.4, código 19.

---

# Encajoy 0.5.3 — tambores visibles y petardos

Los pequeños emojis de los bordes de la tarjeta central se sustituyen por dos tambores vectoriales propios de 38×38 píxeles CSS, con baquetas, cuerpo rojo y aros dorados. Ahora están debajo del aro, a ambos lados de la felicitación. El nombre y la puntuación recuperan todo el ancho de la tarjeta. Se reservan 26 píxeles más en la franja inferior, incluidos los diseños de pantalla baja y fin de partida.

Los petardos visuales se dibujan en una franja separada bajo los nombres: dos ráfagas de doce chispas de mayor tamaño y tres colores, con brillo y duración de 1,1 segundos. El líder vuelve a celebrarse al regresar al centro, con un margen mínimo de ocho segundos. Un refresco sin cambio de llegada no repite la ráfaga. No se añaden explosiones sonoras automáticas. Se mantienen la reducción de movimiento y la opción de efectos, los controles, la recogida inferior de piezas y el resto del juego.

Pruebas Node del juego y del líder/partículas aprobadas; ocho pruebas Python de servidor aprobadas. Versión 0.5.3, código 18. Compilación y comprobación visual en Android pendientes.

---

# Encajoy 0.5.2 — agarre inferior y felicitación al líder

La zona para recoger piezas se extiende desde la bandeja hasta el borde superior del carrusel, incluido el texto de posición provisional y los espacios entre filas. La columna se determina por los centros de las tres piezas: tocar debajo recoge esa pieza, aunque el dedo esté muy abajo. Una columna vacía no recoge otra figura. El tablero y el carrusel quedan fuera de esa zona. Se conserva la ampliación inmediata, la elevación de la pieza, la predicción luminosa y la captura del puntero.

El pueblo con la mayor puntuación vigente muestra dos tambores, uno a cada lado del nombre central, y el texto ¡Enhorabuena, líder! Cuando llega al centro aparecen veinte partículas de petardos visuales y un breve movimiento de los tambores. No interceptan toques. La misma marca tiene un margen de un minuto entre ráfagas para evitar repetir continuamente la celebración; un refresco de datos no acumula partículas. Los empates en cabeza reciben el mismo reconocimiento. Si el resultado caduca o deja de ser líder, se retiran los adornos. Reducir movimiento deja solo tambores estáticos y la felicitación. Los petardos del carrusel son visuales, sin explosiones sonoras automáticas; el redoble del final de ronda se conserva.

Validación: pruebas de las tres columnas con el dedo en el texto inferior, exclusión de tablero/carrusel, columna vacía, limpieza de gestos, líder real, cambio de líder, caducidad, límite de repetición y reducción de movimiento aprobadas. También pasan las pruebas anteriores y ocho pruebas Python de servidor. Versión 0.5.2, código 17. Compilación y comprobación real del tacto y aspecto en el móvil pendientes.

Subir el ZIP con el mismo nombre sin descomprimir, sustituyendo el anterior.

---

# Encajoy 0.5.1 — recoger, arrastrar y anticipar líneas

Correcciones a partir de las tres capturas de referencia del usuario:

- Toda la altura de cada columna de la bandeja sirve para recoger su pieza, incluido el espacio vacío bajo la figura.
- La figura se amplía a la escala de las casillas al pulsar, antes del primer movimiento. Con dedo o lápiz queda elevada por encima del punto de contacto. Con ratón se centra bajo el puntero.
- Al pasar por un hueco válido se anticipa la colocación y se iluminan todas las filas/columnas que se completarían, con un haz de luz. El cálculo usa una vista temporal: no modifica tablero, puntos ni piezas hasta soltar.
- Se recalcula la posición al soltar. Una posición inválida conserva la pieza; cancelar el gesto o perder la captura del puntero limpia la figura flotante y las luces.
- Un toque sin desplazamiento mantiene la alternativa seleccionar pieza y tocar casilla. Se evita que el clic posterior duplique la acción.

Se mantienen Clásico relajante, Contra pueblos, temas, clasificación y los datos guardados. Son cambios propios basados en las capturas; no se ha accedido al código interno ni controlado la app Block Blast del móvil.

Validación: pruebas de recogida inmediata, figura elevada, predicción simultánea de fila y columna, ausencia de cambios durante la vista previa, cancelación, toque simple, soltado inválido y colocación real aprobadas, además de las pruebas anteriores y ocho pruebas Python de servidor. Versión 0.5.1, código 16. Compilación de la APK y comprobación táctil/visual en dispositivo pendientes.

---

# Encajoy 0.5.0 — calma y pueblos

Clásico es el modo principal y se reanuda al abrir la app. Dos botones superiores permiten cambiar entre Clásico y Contra pueblos sin borrar partidas. Reto diario sigue accesible en Ajustes.

## Clásico

Sin reloj visible ni límite de tiempo. Se conservan el comienzo sencillo, las tres piezas, las reglas y el guardado automático de cada movimiento. Paleta Calma, tonos sinusoidales más suaves y una estrella por casilla eliminada. Los mensajes de una sola línea son discretos. El corazón y el fondo rosa se reservan para vaciar el tablero con varias líneas o alcanzar combos múltiplos de diez.

## Contra pueblos

Se conservan los tres minutos y las reglas easy-v1 compatibles con el servidor. El enlace Clasificación muestra las mejores marcas vigentes de cada pueblo, tu posición y la diferencia para superar al siguiente. Los empates comparten puesto. Durante la ronda se indica una posición provisional: no se publica nada automáticamente. Solo al terminar se puede publicar voluntariamente; no se necesitan cuenta ni GPS.

Al completar una ronda con puntos se escucha un redoble breve. Los aplausos y globos se reservan para un nuevo récord personal o una mejora de puesto confirmada después de publicar y refrescar los resultados. Se respeta el silencio, el volumen y la reducción de movimiento. El resultado puede cerrarse de inmediato.

## Motivos para volver

El reto diario indica su objetivo y conserva la marca de completado durante ese día. Objetivos: seis líneas, racha de tres o 150 puntos. No hay penalización por faltar.

Los temas de colores se eligen en Ajustes → Colores · Temas: Calma desde el principio, Bosque a las 20 líneas y Atardecer a las 60 líneas acumuladas desde esta versión. No se suman retroactivamente líneas desconocidas de partidas antiguas. Cambiar colores conserva el tablero, la puntuación y los identificadores de color usados por el servidor.

Se mantienen el aro curvo de pueblos, la caducidad de una hora, los récords anteriores y los controles para salir de Ver tablero. El modo interno timed mantiene su clave de guardado aunque ahora se llame Contra pueblos.

## Validación y entrega

Pruebas Node de juego, guardado/cambio de modo, clasificación/empates/diferencias, ausencia de puestos ficticios, desbloqueo de temas, objetivo diario y celebración según récord aprobadas. Ocho pruebas Python de servidor aprobadas. Versión 0.5.0, código 15. No se ha compilado una APK ni validado la presentación y el sonido en Android en este entorno; esas verificaciones quedan pendientes.

Subir Encajoy-0.1.0-Proyecto.zip sin descomprimir a la raíz del repositorio y reemplazar el anterior. El workflow existente compila esa ruta. La clasificación compartida requiere conexión y el servicio de comunidad configurado; sin conexión se puede seguir jugando, sin publicar esa ronda.

---

# Encajoy 0.4.4 — aro curvo como Órbita Flash

Se reutiliza la geometría de ocho paneles curvos del carrusel propio de Órbita Flash: tres caras delanteras y cinco traseras. Marco dorado, fondo azul oscuro, nombre central destacado, puntuación y señal verde de dirección. La franja inferior reserva más altura para mostrar el conjunto.

Cada resultado ocupa una sola superficie. Con dos pueblos se ven un pueblo central, otro en un panel lateral y los demás paneles vacíos; no se inventan participantes para llenar ambos lados. Al girar, los nombres viajan con sus paneles y la etiqueta central se oculta durante la transición para no quedar flotando. Con hasta ocho pueblos se conservan sus posiciones físicas en el aro; con más, se renuevan las caras que pasan por detrás. Un único pueblo permanece legible sin giro automático.

Se conservan los controles y la pausa temporal al deslizar, la caducidad de una hora, el redoble, las celebraciones y las correcciones de la versión anterior. No se cambia Órbita Flash ni se modifica el servidor.

Pruebas: geometría comparada con Órbita Flash, cero/uno/dos/tres/ocho/cincuenta resultados sin tarjetas duplicadas, giro/interrupción, pruebas de juego/audio y ocho pruebas Python de servidor aprobadas. Versión 0.4.4, código 14. Compilación Android y revisión del aspecto final en móvil pendientes.

---

# Encajoy 0.4.3 — pueblos y celebración

Correcciones a partir de los vídeos del 10 de noviembre de 2026:

- Cada pueblo ocupa una tarjeta real, sin clonar el vecino cuando solo hay dos. Si existen varias publicaciones del mismo nombre (ignorando mayúsculas y espacios), el carrusel muestra la de mayor puntuación aún vigente. No se altera la base de datos del servidor.
- Giro circular visible de 1,6 segundos cada ocho segundos. Las flechas y el deslizamiento hacen una pausa temporal de cinco segundos; el siguiente turno automático reanuda el movimiento. El botón de pausa explícita sigue disponible. Un único pueblo queda estable y legible.
- Redoble generado de 0,9 segundos al completar Contrarreloj con puntos, seguido de aplausos y globos/confeti. Respeta silencio y volumen. No se repite al reabrir el resultado y se cancela al reiniciar, revisar el tablero u ocultar la aplicación. Los controles de resultado están disponibles de inmediato.
- Eliminaciones con onda de luz multicolor, mensajes mayores y pulso de puntuación. Se conservan partículas, combos, corazón y fondo rosa de la versión anterior. Son recursos propios; no se incluyen archivos de Block Blast.
- Se conservan datos, récords, modos, comunidad opcional y reglas de puntuación. Los controles para salir de Ver tablero siguen visibles.

Validación: pruebas Node de juego/carrusel/audio y ocho pruebas Python de servidor aprobadas. Versión Android 0.4.3, código 13. Compilación de APK y prueba visual/sonora en móvil pendientes; este ZIP contiene el proyecto, no una APK compilada.

Subir Encajoy-0.1.0-Proyecto.zip sin descomprimir a la raíz del repositorio, reemplazando el archivo del mismo nombre. El workflow existente compila esa ruta.

---

# Encajoy 0.4.2 — carrusel circular de pueblos

La franja inferior se sustituye por tarjetas curvas en círculo, con nombre completo y puntos en el centro. Giro cada ocho segundos cuando hay varios resultados, flechas para avanzar y retroceder, deslizamiento y botón para pausar o continuar. Con un único pueblo permanece visible en el centro; las tarjetas sin datos son decorativas. No se inventan localidades ni puntuaciones.

Las publicaciones siguen caducando individualmente al cabo de una hora y la comunidad sigue siendo opcional. Los nombres se dibujan como texto. El tablero se adapta a la altura disponible para que el carrusel y los controles finales quepan en pantalla. Se respeta la reducción de movimiento y la preferencia de efectos.

Validación: pruebas de juego y ocho pruebas de servidor aprobadas; comprobadas navegación, pausa, interrupción de animaciones, 50 participantes, resultado único y caducidad. Compilación Android y revisión visual en móvil pendientes de GitHub Actions y prueba en dispositivo.

## Corrección 0.4.2

Al elegir Ver tablero, quedan visibles Jugar otra vez y Ver resultado. Ambos caminos funcionan en los tres modos, también al recuperar una partida terminada desde los datos guardados. El acceso Ver resultado de Ajustes funciona ahora en Clásico y Diario además de Contrarreloj. Cerrar el resultado mediante el evento cancelar también devuelve al tablero con las dos salidas visibles.
Un rombo propio azul cian palpita detrás de la puntuación durante la partida. Diez estrellas pequeñas, con posiciones fijas y animación de opacidad, aparecen en el área del tablero sin interceptar toques ni modificar las celdas. No se crean nuevas estrellas indefinidamente.
Al dejar el tablero vacío o alcanzar un combo múltiplo de cinco, aparece un corazón vectorial original y un cambio de fondo a rosa durante 1,7 segundos. El corazón se desvanece en 1,15 segundos y no captura entradas. No se añaden puntos por el efecto: los puntos continúan calculándose con las mismas reglas.
Efectos visuales se puede desactivar desde Ajustes. Se respeta Reducir movimiento del sistema. Al reiniciar o cambiar de modo se limpian el corazón, los temporizadores y el tinte rosa. Las animaciones ambientales se pausan cuando la página queda oculta.
Versión interna 0.4.2, código 12. Pruebas de los tres recorridos de fin de partida, reanudación de partida terminada, limpieza de efectos, preferencia de efectos y reducción de movimiento aprobadas. Las ocho pruebas de servidor siguen aprobadas. La compilación Android y la inspección visual real en un dispositivo siguen pendientes.

## Cambios 0.4.0

Clásico y Diario tienen variedad de piezas pequeñas, barras de 4 y 5, rectángulos de 6 y cuadrados de 3×3. Las primeras tandas de una partida nueva son más sencillas. No se promete un algoritmo idéntico al juego de referencia ni se han copiado recursos de ese juego.
No hay límite de tiempo ni reloj visible en Clásico/Diario. El tiempo local sigue registrándose internamente para conservar la información de la partida. Contrarreloj mantiene 3 minutos y el generador easy-v1 compatible con el servidor existente.
Las filas/columnas completas se eliminan simultáneamente. Los bloques se iluminan y desaparecen con una onda luminosa y partículas. La entrada se bloquea como máximo 420 ms durante la animación para no colocar piezas detrás de un efecto; se respeta la preferencia de reducir movimiento.
Los combos de Clásico/Diario sobreviven dos colocaciones sin eliminar; se cortan con la tercera. Una nueva eliminación aumenta el multiplicador y renueva el margen. Contrarreloj conserva la regla anterior (eliminaciones en colocaciones consecutivas), por lo que el servidor no requiere actualización.
La partida se acaba cuando no cabe ninguna de las piezas restantes, también si la bandeja todavía conserva una o dos piezas; no se espera una nueva tanda que el jugador no podría llegar a recibir. Solo se reparten otras tres al colocar todas las anteriores.
Vibración breve al eliminar líneas, desactivable en Ajustes y respetando la configuración háptica de Android. No se solicita permiso VIBRATE. No hay vibración desde la versión HTML fuera de Android.
Se conservan los datos locales, las piezas guardadas y los récords. Las siguientes tandas de partidas Clásico/Diario existentes pasan al conjunto variado. Los récords con reglas distintas no son directamente comparables. Identificador de app sin cambios, versión 0.4.0 (código 10).
Se han probado las piezas grandes, la falta de límite de tiempo, la eliminación simultánea, la tolerancia de combos, la preferencia de vibración, la comunidad, los reinicios y las ocho pruebas del servidor. Las animaciones, el tacto y la instalación deben revisarse en Android tras compilar el ZIP. La compilación Android no se ha ejecutado en este entorno.

## Rediseño 0.3.1

La pantalla principal se reorganiza a partir de la referencia del usuario: récord con corona, nombre discreto y engranaje arriba; puntuación grande centrada; tablero de celdas vacías apenas visibles; tres piezas de bloques biselados debajo. Los modos, volumen, nivel, reinicio, compartir y privacidad pasan al diálogo Ajustes. Se mantienen los relojes y una franja discreta de pueblos.
La confirmación de reinicio y el texto para compartir usan diálogos del propio juego, sin alertas con título JavaScript. Se añade respuesta visual al borrar líneas y encadenar combos sin cambiar la puntuación ni las reglas del servidor. El aviso inicial de privacidad se acorta y la explicación de la comunidad queda desplegable; el consentimiento publicitario de Google sigue necesitando configurar AdMob.
Versión interna 0.3.1, código 9. Pruebas de juego, cancelación/confirmación del reinicio, cambio de modos, pausa del reloj en ajustes y ocho pruebas del servidor aprobadas. Compilación Android y comparación visual final en un móvil pendientes; no se dispone de navegador/emulador operativo en este entorno. No se presenta una imagen generada como captura real de la APK.

## Corrección de compilación conservada de 0.3.0

Activado `android.useAndroidX=true`, necesario para las dependencias AndroidX del SDK Google UMP. Se conserva 0.3.0 (código 8), dado que la compilación anterior no produjo APK.

## Cambios de esta entrega

- Tablero más grande sobre fondo azul, bloques con relieve y bandeja de tres piezas sin cajas grandes. Diseño propio inspirado en el tipo de interacción de la referencia; no se incluyen recursos ni marca de Block Blast.
- Arrastre táctil con la pieza completa centrada y elevada 28 píxeles sobre el dedo. Previsualización del color en el hueco válido; los intentos que no caben conservan la pieza y los puntos.
- Reloj visible en todos los modos: tiempo jugado en Clásico y Diario, 3 minutos restantes en Contrarreloj. Las reglas de puntuación y verificación del servidor se conservan.
- Resultado de Clásico/Diario con botón Jugar otra vez. Reinicio local inmediato, sin anuncios intermedios.
- Aviso de privacidad al primer inicio y acceso permanente. La comunidad requiere activación voluntaria y la publicación de cada pueblo sigue siendo opcional. Al desactivarla se detienen nuevas consultas de comunidad; una petición ya enviada no puede retirarse.
- Google UMP 4.0.0 integrado en Android. El estado publicitario se consulta al SDK, nunca a una casilla local. El juego no integra todavía SDK de anuncios ni genera ingresos por publicidad.

## Activar el formulario publicitario real

Falta el ID de la aplicación del propietario en AdMob y un mensaje publicado en Privacidad y mensajes de esa cuenta. No se usa el ID de otra aplicación ni se copia la lista de proveedores de Block Blast.
Configurar la variable de compilación ENCAJOY_ADMOB_APP_ID, o pasar `-PencajoyAdmobAppId=ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY`.
Con ese ID, la app llama al SDK oficial para actualizar el estado y mostrar el formulario cuando corresponda. Ofrece Preferencias de publicidad si el SDK lo exige. Si falla la conexión, el juego sigue disponible sin publicidad.
Sin ID configurado, esta versión muestra la información de privacidad del propio juego y no solicita el formulario publicitario. Esto NO equivale a obtener consentimiento para anuncios futuros. Antes de activar publicidad hay que completar la configuración, probar el formulario con dispositivos de prueba y usar canRequestAds() como puerta de acceso de cualquier integración publicitaria.

## Descargar y compilar

Este ZIP mantiene el nombre `Encajoy-0.1.0-Proyecto.zip` y la raíz `encajoy/`, de modo que basta sustituirlo en la raíz del repositorio. El workflow existente puede compilarlo. Aunque el artefacto conserve el nombre antiguo, la versión interna será 0.4.2 (código 12).
No se ha generado una nueva APK en esta sesión: faltan SDK Android/Gradle locales y acceso a sus descargas. Las pruebas JavaScript y las ocho pruebas de servidor han pasado; la compilación con UMP, la revisión visual y la instalación en Android deben validarse en CI y en el móvil.
La firma de las APK debug anteriores no se incluye en el proyecto. El workflow actual genera una clave debug en el runner: no se garantiza actualización sobre instalaciones anteriores. No desinstalar una instalación con datos importantes para resolver una firma incompatible; primero hay que recuperar la clave original o preparar una migración. No se ha cambiado el identificador de aplicación ni las claves de almacenamiento local.

## Funciones y servicio conservados

Incluye volumen en Ajustes, con botones −/+, porcentaje y silencio; dificultad fácil constante en los tres modos (más piezas pequeñas, ninguna pieza de 3×3 ni de 6 bloques); globos, confeti y aplausos sintetizados al completar los 3 minutos con puntos. Las partidas guardadas de versiones anteriores conservan sus piezas actuales; las nuevas tandas usan las reglas fáciles. Los récords anteriores se conservan y no son directamente comparables con estas reglas.

Al completar Contrarreloj se puede publicar de forma opcional el pueblo y la puntuación. Una ronda que termina por falta de huecos antes de los 3 minutos no permite publicar. No hay límite de 20 o 50 ganadores: todos los que completan una ronda con puntos pueden participar. El servidor comprueba las jugadas y calcula los puntos; no acepta una puntuación inventada en la petición. No es un sistema antitrampas de competición profesional: no evita bots ni modificación del reloj local o elección de semillas ventajosas. No hay premios económicos.

El cuadro junto a puntos, récord y racha muestra un pueblo cada 8 segundos y se consulta de nuevo al servidor cada minuto. Cada publicación caduca exactamente una hora después de recibirse; cada móvil la oculta según la hora del servidor y la lista se limpia físicamente como máximo un minuto después. Con 50 pueblos, una vuelta completa tarda 6 minutos y 40 segundos. Los nombres no tapan ni reciben toques sobre el tablero. Se muestran en los tres modos, aunque solo Contrarreloj permite publicar.

## Estado real de esta entrega

Servicio instalado por el usuario en DigitalOcean y túnel independiente de Cloudflare en buen estado. La captura del usuario confirma que `/health` devuelve `{"ok":true,"rules":"easy-v1"}`. El proyecto ya configura `https://encajoy.adam-tunnel.online` en `app/src/main/assets/community-config.json`. Falta compilar esta versión y comprobar una publicación real desde Android y su visualización en otro móvil. Las rondas ya terminadas sin conexión no se pueden publicar: iniciar Nueva partida en Contrarreloj después de instalar esta versión. Nunca se muestran nombres de prueba como si fuesen jugadores reales. No se han modificado los servicios de Adam Tunnel. El conector del juego usa el servicio independiente `encajoy-tunnel`, mientras que el API usa `encajoy-community`.

## Instalar en DigitalOcean (Ubuntu con systemd)

1. Subir este proyecto o descargar su ZIP del repositorio propio y descomprimirlo en una carpeta temporal.
2. Desde la raíz `encajoy`, ejecutar `sudo sh server/install.sh`. Instala un servicio separado que escucha solo en `127.0.0.1:8787`. No cambia VPN, DNS, puertos públicos ni proxy. Conserva la clave existente al actualizar. Guarda SQLite en `/var/lib/encajoy-community`. La clave está en `/etc/encajoy-community.env`; no se debe compartir ni incluir en la APK.
3. Revisar el proxy HTTPS actual antes de modificarlo. Si es Nginx, añadir el bloque de `server/nginx-location.conf` dentro del bloque HTTPS del dominio adecuado, sin sustituir su configuración actual. Comprobar con `sudo nginx -t` antes de recargar. Si utiliza otro proxy o Xray ocupa el puerto 443, adaptar la ruta a esa instalación; no instalar otro proceso sobre ese puerto sin revisarla.
4. Comprobar desde fuera del servidor `https://TU-DOMINIO/encajoy/health`: debe devolver `{"ok":true,"rules":"easy-v1"}`. Verificar el certificado y la conectividad desde Android.
5. Ejecutar `python3 configure_community.py https://TU-DOMINIO/encajoy` en el proyecto antes de crear el ZIP de compilación. La APK solo deja pasar peticiones HTTPS a `/towns` y `/rounds` de esa ruta.
6. Compilar y probar dos móviles: terminar una ronda, publicar Azpeitia, comprobar que aparece en ambos; alternar nombres y confirmar desaparición a la hora.

Diagnóstico local: `sudo systemctl status encajoy-community` y `curl http://127.0.0.1:8787/health`. Para detenerlo: `sudo systemctl stop encajoy-community`.

## Datos y funcionamiento

Solo se publica el texto del pueblo y los puntos; no se pide GPS, cuenta ni correo. El cuadro avisa al usuario antes de publicar. La ciudad se limita a 2–40 caracteres y letras, espacios, apóstrofes, puntos y guiones. Esto no demuestra que sea un municipio real ni sustituye la moderación de contenido. El servicio no guarda registros de IP ni jugadas: usa las IP solo en memoria para limitar peticiones; los registros de Nginx/Cloudflare dependen de su configuración y deben revisarse en la política de privacidad antes de publicar esta función.

Se requiere conexión al iniciar la primera jugada para obtener un identificador de ronda, y al publicar. La ronda se inicia cuando se puede colocar la primera pieza, aunque la petición inicial tarde unos segundos. Si falla la conexión, se puede jugar pero esa ronda no publica. La publicación puede enviarse hasta 15 minutos después de solicitar la ronda. Los reintentos de la misma ronda no duplican el pueblo ni reinician la hora. La lista gira por publicaciones, no por mejores puntuaciones. Hay protecciones básicas de tamaño, frecuencia, firmas y comprobación de jugadas. No hay anuncios, compras ni cuentas añadidas.

## Compilación y validación

Android 35, Java 17, Gradle 8.9, versión 0.4.2 (código 12). La raíz del ZIP sigue siendo `encajoy/` y su nombre sigue siendo `Encajoy-0.1.0-Proyecto.zip` para mantener el workflow ya instalado. Compila con `gradle :app:assembleDebug`. El nombre del artefacto antiguo no determina la versión interna del juego.

Ejecutar desde la raíz:

```
node tests/game.test.cjs
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

Las pruebas cubren volumen, reglas fáciles, reloj por modo, fin de ronda, envío opcional, desconexión, 50 nombres y caducidad individual, validación de jugadas, firmas y reintentos. El replay generado por JavaScript se compara con el cálculo Python. La compilación Android con UMP y la revisión visual en móvil quedan pendientes. Mantener una clave de firma estable antes de distribuir actualizaciones públicas: las compilaciones debug en CI pueden usar claves distintas entre ejecuciones.
