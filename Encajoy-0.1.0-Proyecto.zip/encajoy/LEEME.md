# Encajoy 0.2.2 — versión de prueba

Incluye volumen solo en la cabecera, con botones −/+, porcentaje y silencio; dificultad fácil constante en los tres modos (más piezas pequeñas, ninguna pieza de 3×3 ni de 6 bloques); globos, confeti y aplausos sintetizados al completar los 3 minutos con puntos. Las partidas guardadas de versiones anteriores conservan sus piezas actuales; las nuevas tandas usan las reglas fáciles. Los récords anteriores se conservan y no son directamente comparables con estas reglas.

Al completar Contrarreloj se puede publicar de forma opcional el pueblo y la puntuación. Una ronda que termina por falta de huecos antes de los 3 minutos no permite publicar. No hay límite de 20 o 50 ganadores: todos los que completan una ronda con puntos pueden participar. El servidor comprueba las jugadas y calcula los puntos; no acepta una puntuación inventada en la petición. No es un sistema antitrampas de competición profesional: no evita bots ni modificación del reloj local o elección de semillas ventajosas. No hay premios económicos.

El cuadro junto a puntos, récord y racha muestra un pueblo cada 8 segundos y se consulta de nuevo al servidor cada minuto. Cada publicación caduca exactamente una hora después de recibirse; cada móvil la oculta según la hora del servidor y la lista se limpia físicamente como máximo un minuto después. Con 50 pueblos, una vuelta completa tarda 6 minutos y 40 segundos. Los nombres no tapan ni reciben toques sobre el tablero. Se muestran en los tres modos, aunque solo Contrarreloj permite publicar.

## Estado real de esta entrega

Servicio instalado por el usuario en DigitalOcean y túnel independiente de Cloudflare en buen estado. La captura del usuario confirma que `/health` devuelve `{"ok":true,"rules":"easy-v1"}`. El proyecto ya configura `https://encajoy.adam-tunnel.online` en `app/src/main/assets/community-config.json`. Falta compilar esta versión y comprobar una publicación real desde Android y su visualización en otro móvil. Las rondas ya terminadas sin conexión no se pueden publicar: iniciar Nueva partida en Contrarreloj después de instalar esta versión. Nunca se muestran nombres de prueba como si fuesen jugadores reales. No se han modificado los servicios de Adam Tunnel. El conector del juego usa el servicio independiente `encajoy-tunnel`, mientras que el API usa `encajoy-community`.

## Instalar en DigitalOcean (Ubuntu con systemd)

1. Subir este proyecto o descargar su ZIP del repositorio propio y descomprimirlo en una carpeta temporal.
2. Desde la raíz `encajoy`, ejecutar `sudo sh server/install.sh`. Instala un servicio separado que escucha solo en `127.0.0.1:8787`. No cambia VPN, DNS, puertos públicos ni proxy. Conserva la clave existente al actualizar. Guarda SQLite en `/var/lib/encajoy-community`. La clave está en `/etc/encajoy-community.env`; no se debe compartir ni incluir en la APK.
3. Revisar el proxy HTTPS actual antes de modificarlo. Si es Nginx, añadir el bloque de `server/nginx-location.conf` dentro del bloque HTTPS del dominio adecuado, sin sustituir su configuración actual. Comprobar con `sudo nginx -t` antes de recargar. Si utiliza otro proxy o Xray ocupa el puerto 443, adaptar la ruta a esa instalación; no instalar otro proceso sobre ese puerto sin revisarla.
4. Comprobar desde fuera del servidor `https://TU-DOMINIO/encajoy/health`: debe devolver `{"ok":true,"rules":"easy-v1"}`. Verificar el certificado y la conectividad desde Android.
5. Ejecutar `python3 configure_community.py https://TU-DOMINIO/encajoy` en el proyecto antes de crear el ZIP de compilación. La APK solo deja pasar peticiones HTTPS a `/towns` y `/rounds` de esa ruta.
6. Compilar y probar dos móviles: terminar una ronda, publicar Azpeitia, comprobar que aparece en ambos; alternar nombres y confirmar desaparición a la hora.

Diagnóstico local: `sudo systemctl status encajoy-community` y `curl http://127.0.0.1:8787/health`. Para detenerlo: `sudo systemctl stop encajoy-community`.

## Datos y funcionamiento

Solo se publica el texto del pueblo y los puntos; no se pide GPS, cuenta ni correo. El cuadro avisa al usuario antes de publicar. La ciudad se limita a 2–40 caracteres y letras, espacios, apóstrofes, puntos y guiones. Esto no demuestra que sea un municipio real ni sustituye la moderación de contenido. El servicio no guarda registros de IP ni jugadas: usa las IP solo en memoria para limitar peticiones; los registros de Nginx/Cloudflare dependen de su configuración y deben revisarse en la política de privacidad antes de publicar esta función.

Se requiere conexión al iniciar la primera jugada para obtener un identificador de ronda, y al publicar. La ronda se inicia cuando se puede colocar la primera pieza, aunque la petición inicial tarde unos segundos. Si falla la conexión, se puede jugar pero esa ronda no publica. La publicación puede enviarse hasta 15 minutos después de solicitar la ronda. Los reintentos de la misma ronda no duplican el pueblo ni reinician la hora. La lista gira por publicaciones, no por mejores puntuaciones. Hay protecciones básicas de tamaño, frecuencia, firmas y comprobación de jugadas. No hay anuncios, compras ni cuentas añadidas.

## Compilación y validación

Android 35, Java 17, Gradle 8.9, versión 0.2.2 (código 7). La raíz del ZIP sigue siendo `encajoy/` y su nombre sigue siendo `Encajoy-0.1.0-Proyecto.zip` para mantener el workflow ya instalado. Compila con `gradle :app:assembleDebug`. El nombre del artefacto antiguo no determina la versión interna del juego.

Ejecutar desde la raíz:

```
node tests/game.test.cjs
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

Las pruebas cubren volumen, reglas fáciles, reloj por modo, fin de ronda, envío opcional, desconexión, 50 nombres y caducidad individual, validación de jugadas, firmas y reintentos. El replay generado por JavaScript se compara con el cálculo Python. La compilación Android y la revisión visual en móvil quedan pendientes. Mantener una clave de firma estable antes de distribuir actualizaciones públicas: las compilaciones debug en CI pueden usar claves distintas entre ejecuciones.
