package es.encajoy.game;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Android-only HTTPS transport for the first-party community API. */
public final class CommunityBridge {
    private final Activity activity;
    private final WebView web;
    private final String base;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    CommunityBridge(Activity activity, WebView web, String base) {
        this.activity=activity; this.web=web; this.base=base;
    }
    @JavascriptInterface public void request(int id, String path, String method, String body) {
        if(id<1 || id>100000000 || !("/towns".equals(path)||"/rounds".equals(path)) ||
            !("GET".equals(method)&&"/towns".equals(path) || "POST".equals(method))) {
            respond(id, 400, "{\"error\":\"Solicitud no permitida\"}");return;
        }
        worker.execute(()->{
            HttpURLConnection connection=null;
            try {
                connection=(HttpURLConnection)new URL(base+path).openConnection();
                connection.setRequestMethod(method);
                connection.setConnectTimeout(9000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Accept","application/json");
                connection.setRequestProperty("Cache-Control","no-store");
                if("POST".equals(method)) {
                    byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
                    if(bytes.length>10000)throw new IllegalArgumentException("Solicitud demasiado grande");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    try(OutputStream out=connection.getOutputStream()){out.write(bytes);}
                }
                int status=connection.getResponseCode();
                InputStream input=status>=400?connection.getErrorStream():connection.getInputStream();
                String response="{}";
                if(input!=null)try(InputStream in=input){
                    byte[] bytes=in.readNBytes(65536);
                    response=new String(bytes,StandardCharsets.UTF_8);
                }
                respond(id,status,response);
            }catch(Exception ex){respond(id,0,"{\"error\":\"No se pudo conectar al servidor de pueblos.\"}");}
            finally{if(connection!=null)connection.disconnect();}
        });
    }
    private void respond(int id,int status,String body){
        try {
            JSONObject response=new JSONObject();
            response.put("id",id);response.put("status",status);response.put("body",body);
            String js="window.__encajoyNativeReply&&window.__encajoyNativeReply("+response+");";
            activity.runOnUiThread(()->{if(!activity.isFinishing()&&!activity.isDestroyed())web.evaluateJavascript(js,null);});
        }catch(Exception ignored){}
    }
    void close(){worker.shutdownNow();}
}
