const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
class Element{
 constructor(){this.children=[];this.style={setProperty(){}};this.dataset={};this.classes=new Set();this.classList={add:n=>this.classes.add(n),remove:n=>this.classes.delete(n),contains:n=>this.classes.has(n)};this.hidden=false;this.open=false;this.value='';this.textContent='';this.attrs={};}
 addEventListener(name,callback){(this.listeners??={})[name]=callback;}
 append(...items){this.children.push(...items)}
 replaceChildren(...items){this.children=[...items]}
 setAttribute(k,v){this.attrs[k]=v}
 getBoundingClientRect(){return {left:0,top:0,width:40,height:40}}
 contains(node){return node===this||this.children.some(c=>c.contains?.(node))}
 querySelectorAll(){return []}
 showModal(){this.open=true}
 close(){this.open=false}
 remove(){}
 animate(){const animation={};(this.animations??=[]).push(animation);return animation;}
}
let now=1800000000000,networkFail=false,publishBusy=false,requests=[];
const RealDate=Date;
class Clock extends RealDate{constructor(...a){super(...(a.length?a:[now]))}static now(){return now}}
const elements=Object.fromEntries([...html.matchAll(/id="([^"]+)"/g)].map(m=>[m[1],new Element()]));
const storage=new Map();
const context=vm.createContext({console,Date:Clock,Math,Set,Array,Number,String,JSON,Promise,Error,Boolean,
 document:{getElementById:id=>elements[id],createElement:()=>new Element(),createElementNS:()=>new Element(),body:new Element(),addEventListener(){}},
 localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
 window:{ENCAJOY_COMMUNITY_URL:'https://example.test/encajoy'},
 navigator:{},matchMedia:()=>({matches:true}),confirm:()=>true,prompt(){},
 setInterval(){},clearInterval(){},setTimeout(){return 0},clearTimeout(){},AbortController,
 fetch:async(url,options)=>{requests.push({url,options});if(networkFail)throw new Error('offline');if(publishBusy&&url.endsWith('/towns')&&options?.method==='POST')return {ok:false,status:503,json:async()=>({error:'Servicio ocupado'})};return {ok:true,json:async()=>url.endsWith('/rounds')?{token:'test-token'}:options?.method==='POST'?{expiresAt:now+3600000}:{now,towns:[]}}}
});
vm.runInContext(html.match(/<script>([\s\S]*)<\/script>/)[1],context);
const run=s=>vm.runInContext(s,context);
(async()=>{
 await Promise.resolve();
 assert.equal(requests.length,0,'no community request before the optional choice');
 assert.equal(elements.privacy.open,true,'first-run privacy notice');
 elements['community-choice'].checked=true;run("$('privacy-continue').onclick()");
 assert.equal(run('communityEnabled'),true);
 assert.equal(elements.clock.hidden,true,'classic has no visible timer');run("openMode('daily')");assert.equal(elements.clock.hidden,true);
 run("openMode('timed',true)");assert.equal(elements.clock.hidden,false);
 run('setVolume(1000)');assert.equal(run('volume'),1);run('setVolume(-10)');assert.equal(run('volume'),0);
 run('setVolume(60)');run("$('quieter').onclick()");assert.equal(run('volume'),.5);run("$('louder').onclick()");assert.equal(run('volume'),.6);
 assert.equal(JSON.parse(storage.get('orbita-bloques-v1-volume')),.6);
 for(let i=0;i<1000;i++){run('refill()');assert.equal(run('state.tray.every(p=>p.shape<=7)'),true)}
 run("openMode('timed',true,12345)");
 assert.equal(run('state.deadline'),0);
 await run('place(0,0)');
 assert.equal(requests.filter(r=>r.url.endsWith('/rounds')).length,1);
 assert.equal(run('state.moves.length'),1);assert.equal(run('state.deadline'),now+180000);
 now+=180000;run('syncClock()');
 assert.equal(run('state.over'),true);assert.equal(elements.result.open,true);assert.equal(elements['city-form'].hidden,false);
 assert.equal(elements['result-title'].textContent,'¡Nuevo récord personal!');
 publishBusy=true;elements.city.value='Azpeitia';await run("$('publish').onclick()");
 assert.match(elements['publish-note'].textContent,/No se pudo publicar.*503/);
 assert.equal(elements.publish.disabled,false);
 run("inspectBoard();openMode('classic');openMode('timed');reopenResult()");
 assert.equal(elements.city.value,'Azpeitia');assert.equal(run('state.moves.length'),1);
 publishBusy=false;await run("$('publish').onclick()");assert.equal(run('state.published'),true);assert.equal(elements['town-name'].textContent,'Azpeitia','confirmed POST remains visible even if the list is stale');
 const publication=requests.find(r=>r.url.endsWith('/towns')&&r.options?.method==='POST');
 assert.equal(JSON.parse(publication.options.body).city,'Azpeitia');
 const count=requests.length;elements.city.value='<script>';await run("$('publish').onclick()");assert.equal(requests.length,count);
 run('towns=Array.from({length:50},(_,i)=>({id:String(i),city:"Pueblo "+i,score:i,expiresAt:Date.now()+3600000}));townCursor=0;rotateTown(false)');
 for(let i=1;i<=50;i++){run('rotateTown()');assert.equal(elements['town-name'].textContent,'Pueblo '+(i%50))}
 // Exercise real curved transitions, including interruption by a refresh or another navigation.
 const frames=[];context.requestAnimationFrame=callback=>frames.push(callback);context.matchMedia=()=>({matches:false});
 run('rotateTown()');assert.equal(frames.length,1);
 frames.shift()(0);frames.shift()(300);
 for(const card of elements['town-ring'].children)assert.equal(/NaN|Infinity/.test(card.children[0].attrs.d),false);
 frames.shift()(1600);assert.equal(frames.length,0,'one turn ends without a permanent animation loop');
 run('rotateTown();rotateTown(false)');frames.shift()(0);assert.equal(frames.length,0,'refresh cancels the pending transition');
 run('townCursor=0;rotateTown(false)');context.matchMedia=()=>({matches:true});
 // Carousel navigation pauses automatic rotation and keeps full central names as text.
 run("$('town-prev').onclick()");assert.equal(elements['town-name'].textContent,'Pueblo 49');assert.equal(run('townPaused'),true);
 run("$('town-next').onclick()");assert.equal(elements['town-name'].textContent,'Pueblo 0');
 run("$('town-toggle').onclick()");assert.equal(run('townPaused'),false);
 run('towns=[{id:"only",city:"Azkoitia",score:659,expiresAt:Date.now()+3600000}];townCursor=0;rotateTown(false)');
 assert.equal(elements['town-name'].textContent,'Azkoitia');assert.equal(elements['town-next'].disabled,true);assert.equal(elements['town-ring'].children.length,8);
 run('rotateTown()');assert.equal(elements['town-name'].textContent,'Azkoitia','one genuine result remains readable');
 run('towns[0].city="Villanueva de la Cañada <b>";rotateTown(false)');assert.equal(elements['town-name'].textContent,'Villanueva de la Cañada <b>','towns are text, never HTML');
 // A two-town wheel never clones its only neighbour; repeated city results use the best score.
 run('towns=[{id:"a",city:"Azpeitia",score:852,expiresAt:Date.now()+3600000},{id:"b",city:"Azkoitia",score:805,expiresAt:Date.now()+3600000},{id:"c",city:"  azkoitia  ",score:700,expiresAt:Date.now()+3600000}];townCursor=0;rotateTown(false)');
 assert.equal(run('towns.length'),2);assert.equal(elements['town-ring'].children.length,8);
 assert.equal(new Set(elements['town-ring'].children.map(c=>c.attrs['data-town-id']).filter(Boolean)).size,2);
 context.matchMedia=()=>({matches:false});run('rotateTown()');frames.shift()(0);frames.shift()(800);
 assert.equal(elements['town-front'].hidden,true,'central label must not float above moving cards');
 assert.equal(new Set(elements['town-ring'].children.map(c=>c.attrs['data-town-id']).filter(Boolean)).size,2);
 frames.shift()(1600);assert.equal(elements['town-front'].hidden,false);
 run("$('town-next').onclick()");now+=8000;run('townAutoTick()');assert.equal(run('townPaused'),false,'manual browse resumes automatically');
 run("$('town-toggle').onclick()");now+=16000;run('townAutoTick()');assert.equal(run('townPaused'),true,'explicit pause remains in user control');
 while(frames.length)frames.shift()(2000);
 context.matchMedia=()=>({matches:true});
 now+=3600000;run('rotateTown()');assert.equal(run('towns.length'),0,'entries expire at one hour');
 context.matchMedia=()=>({matches:false});
 run('townPaused=false;townAutoTick()');
 assert.equal(frames.length,1,'empty carousel schedules a real turn');
 frames.shift()(0);
 const beforeTurn=elements['town-ring'].children.map(card=>card.children[0].attrs.d).join('');
 frames.shift()(400);
 assert.notEqual(elements['town-ring'].children.map(card=>card.children[0].attrs.d).join(''),beforeTurn);
 frames.shift()(1600);
 await new Promise(resolve=>setImmediate(resolve));
 context.matchMedia=()=>({matches:true});
 run('towns=[{id:"a",city:"Azpeitia",score:50,expiresAt:Date.now()+1000},{id:"b",city:"Oujda",score:60,expiresAt:Date.now()+9000}];townCursor=0');now+=1000;run('rotateTown(false)');assert.equal(elements['town-name'].textContent,'Oujda','individual expiry');
 networkFail=true;run("openMode('timed',true,5)");await run('place(0,0)');assert.equal(run('state.moves.length'),1);assert.equal(run('Boolean(state.session)'),false,'offline playable without a fake shared result');
 now+=180000;run('syncClock()');assert.equal(elements.publish.hidden,true);
 assert.equal(elements['city-form'].hidden,true,'offline rounds do not show publishing controls');
 assert.equal(elements['save-town'],undefined);
 networkFail=false;run("openMode('timed',true,5)");await run('place(0,0)');run('state.over=true;state.finishedAt=Date.now();finishTimed(false)');assert.equal(elements.publish.hidden,true,'early failure cannot publish');
 run("openMode('classic')");assert.equal(elements.clock.hidden,true);
 // Generate a legal multi-line run for independent Python replay parity checks.
 run("openMode('timed',true,2468);state.onlineAttempted=true");
 for(let i=0;i<120;i++){
   const move=run('(()=>{for(let s=0;s<3;s++)if(state.tray[s])for(let n=0;n<64;n++)if(fits(state.tray[s],n%8,Math.floor(n/8)))return [s,n];return null})()');
   if(!move)break;await run(`place(${move[0]},${move[1]})`);now+=100;
 }
 fs.writeFileSync('/tmp/encajoy-replay.json',run('JSON.stringify({seed:state.initialSeed,moves:state.moves,score:state.score,over:state.over})'));
 // Full-shape touch alignment, invalid drops and replay-safe scoring.
 const geo=run('dragGeometry({shape:5,color:0},137.5,336,true,{left:10,top:20},40,43)');
 assert.equal(geo.index,26);assert.equal(geo.left,96);assert.equal(geo.top,149);
 // A finger below the board can still place a piece in the last row.
 const bottom=run('dragGeometry({shape:0,color:0},30,465,true,{left:10,top:20},40,43)');
 assert.equal(bottom.index,56);
 assert.equal(465-bottom.top-40,104);

 assert.equal(run('dragGeometry({shape:5,color:0},-100,-100,true,{left:10,top:20},40,43).index'),-1);
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=[{shape:5,color:0},null,null]");
 await run('place(0,63)');assert.equal(run('state.score'),0,'invalid drop does not consume or score');assert.equal(run('Boolean(state.tray[0])'),true);
 // Elapsed clocks only progress during active play and freeze behind privacy.
 run('state.started=true;clockTickAt=Date.now()');now+=1000;run('syncClock()');assert.equal(elements['clock-value'].textContent,'0:01');
 run('showPrivacy()');now+=1000;run('syncClock()');assert.equal(elements['clock-value'].textContent,'0:01');
 elements['community-choice'].checked=false;run("$('privacy-continue').onclick()");
 const beforeOffline=requests.length;await run('refreshTowns()');assert.equal(requests.length,beforeOffline,'opt-out stops shared board requests');
 run('window.onPrivacyStatus({configured:true,optionsRequired:true,error:false})');assert.equal(elements['advertising-options'].hidden,false);
 run('window.onPrivacyStatus({configured:false,optionsRequired:false,error:false})');assert.equal(elements['advertising-options'].hidden,true);
 run('state.board=Array.from({length:64},(_,i)=>(Math.floor(i/8)+i%8)%2?1:null);state.tray=[{shape:0,color:0},{shape:5,color:1},{shape:5,color:2}];state.over=false');
 await run('place(0,0)');assert.equal(elements.result.open,true);assert.equal(elements['city-form'].hidden,true);assert.equal(run('state.over'),true);
 run("$('play-again').onclick()");assert.equal(elements.result.open,false);assert.equal(run('state.score'),0);assert.equal(run('state.over'),false);
 assert.equal(JSON.parse(storage.get('orbita-bloques-v1-community-enabled')),false);
 // Restart uses a game dialog, preserving the round if cancelled.
 run("openMode('classic',true);state.score=12;confirm=()=>{throw Error('Native confirm must not run')}");
 run("$('settings-open').onclick()");assert.equal(elements.settings.open,true);
 run("$('restart').onclick()");assert.equal(elements.settings.open,false);assert.equal(elements['restart-dialog'].open,true);assert.equal(run('state.score'),12);
 run("$('restart-cancel').onclick()");assert.equal(elements['restart-dialog'].open,false);assert.equal(run('state.score'),12);
 run("$('restart').onclick();$('restart-confirm').onclick()");assert.equal(run('state.score'),0);assert.equal(elements['restart-dialog'].open,false);
 // Opening settings stops the elapsed counter; switching mode closes settings.
 run('state.started=true;clockTickAt=Date.now()');run("$('settings-open').onclick()");now+=1000;run('syncClock()');assert.equal(run('state.playedMs||0'),0);
 run("$('daily').onclick()");assert.equal(run('mode'),'daily');assert.equal(elements.settings.open,false);assert.equal(elements['mode-name'].textContent,'Reto diario');
 assert.equal(elements.board.children.length,64,'feedback overlay must not become a board cell');
 // A calm classic round can generate the large shapes visible in the reference.
 run("openMode('classic',true);state.score=100;state.seed=123;state.intro=false;seenClassic=new Set()");
 for(let i=0;i<300;i++)run('refill();state.tray.forEach(p=>seenClassic.add(p.shape))');
 for(const shape of [14,15,16,17])assert.equal(run(`seenClassic.has(${shape})`),true,'large classic piece '+shape);
 assert.equal(run('state.tray.every(p=>Boolean(shapes[p.shape]))'),true);
 now+=3600000;run('syncClock()');assert.equal(run('state.over'),false,'classic is never ended by elapsed time');assert.equal(elements.clock.hidden,true);
 // Clear a row and column together, preserving an unrelated occupied cell.
 run("openMode('classic',true);state.intro=false;state.score=100;state.board.fill(null);state.board[0]=3;for(let i=0;i<8;i++){if(i!==4)state.board[24+i]=1;if(i!==3)state.board[i*8+4]=2;}state.tray=[{shape:0,color:0},{shape:1,color:1},{shape:2,color:2}]");
 await run('place(0,28)');assert.equal(run('state.lines'),2);assert.equal(run('state.board.filter(c=>c!==null).length'),1);assert.equal(run('state.board[0]'),3);assert.equal(run('state.score'),201);
 // Classic combo permits two intervening placements; a third miss breaks it.
 run("openMode('classic',true);state.intro=false;state.score=100;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('state.combo'),1);
 await run('place(1,0)');await run('place(2,1)');assert.equal(run('state.combo'),1);
 run('state.tray[0]={shape:0,color:0};for(let i=0;i<7;i++)state.board[i]=0');await run('place(0,7)');assert.equal(run('state.combo'),2);
 run('state.tray=Array.from({length:3},()=>({shape:0,color:0}))');await run('place(0,0)');await run('place(1,1)');await run('place(2,2)');assert.equal(run('state.combo'),0);
 // Timed play retains server-compatible easy-v1 and immediate combo reset.
 run("openMode('timed',true,123);state.onlineAttempted=true;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('state.combo'),1);await run('place(1,0)');assert.equal(run('state.combo'),0);assert.equal(run('state.rules'),'easy-v1');
 let pulses=0,taps=0;
 context.window.EncajoyEffects={line(){pulses++},placement(){taps++}};
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=Array.from({length:3},()=>({shape:0,color:0}));vibration=true");
 await run('place(0,0)');assert.equal(taps,1);
 await run('place(1,0)');assert.equal(taps,1,'invalid moves do not vibrate');
 run('for(let i=0;i<7;i++)state.board[i]=0');
 await run('place(1,7)');assert.equal(pulses,1);assert.equal(taps,1,'clear uses only its own vibration');
 run('vibration=false');await run('place(2,0)');run('celebrate([[0,0]])');
 assert.equal(taps,1);assert.equal(pulses,1,'mute haptics applies to both effects');
 // Regression: inspecting the final board always leaves two visible escape routes.
 for(const m of ['classic','daily','timed']){
   run(`openMode('${m}',true);state.over=true;state.score=172;render()`);
   run(m==='timed'?'finishTimed(false)':'finishLocal()');assert.equal(elements.result.open,true);
   run("$('close-result').onclick()");assert.equal(elements.result.open,false);assert.equal(elements['end-actions'].hidden,false);assert.equal(elements.status.hidden,true);
   run("$('board-result').onclick()");assert.equal(elements.result.open,true);
   elements.result.listeners.cancel({preventDefault(){}});assert.equal(elements.result.open,false);assert.equal(elements['end-actions'].hidden,false);
   run('save(key(),state)');run(`openMode('${m}')`);assert.equal(elements['end-actions'].hidden,false,'resumed finished round still has restart');
   run("$('board-again').onclick()");assert.equal(run('state.over'),false);assert.equal(run('state.score'),0);assert.equal(elements['end-actions'].hidden,true);assert.equal(elements.status.hidden,false);
 }
 // Exercise the actual animation branch, not only reduced-motion early returns.
 context.matchMedia=()=>({matches:false});run('visualEffects=true;syncEffects();setupAmbientStars()');
 assert.equal(elements['ambient-stars'].children.length,10);
 run("openMode('classic',true);state.intro=false;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run('celebrationActive'),true);assert.equal(elements['perfect-effect'].hidden,false,'a single line earns the heart when it empties the board');
 assert.equal(elements.board.children.length,64);assert.equal(elements['clear-effects'].children.filter(e=>e.className==='cell-reward clear-thumb'&&e.textContent==='👍').length,8,'every cleared square gets a thumb');
 assert.equal(run('state.score'),26,'celebration must not invent bonus points');
 run("openMode('classic',true)");assert.equal(run('celebrationActive'),false);assert.equal(elements['perfect-effect'].hidden,true);assert.equal(context.document.body.classList.contains('celebrating'),false);
 elements['visual-effects'].checked=false;run("$('visual-effects').onchange();perfectCelebration()");assert.equal(run('celebrationActive'),false);assert.equal(context.document.body.classList.contains('effects-off'),true);
 elements['visual-effects'].checked=true;run("$('visual-effects').onchange()");context.matchMedia=()=>({matches:true});run('perfectCelebration()');assert.equal(run('celebrationActive'),false,'OS reduction preference wins');
 // Eight curved surfaces stay visible regardless of participant count.
 const referenceGeometry=function podiumRingGeometry(relative){
 const tau=2*Math.PI,backStart=Math.PI/2+.06,backEnd=tau-backStart,step=(backEnd-backStart)/5,gap=.018;
 const ranges=[[-.52,.52],[.56,1.32]];
 for(let i=0;i<5;i++)ranges.push([backStart+i*step+gap,backStart+(i+1)*step-gap]);
 ranges.push([tau-1.32,tau-.56]);
 const k=Math.floor(relative),fraction=relative-k;
 const range=n=>ranges[((n%8)+8)%8].map(t=>t+Math.floor(n/8)*tau);
 const from=range(k),to=range(k+1),a=from[0]+(to[0]-from[0])*fraction,b=from[1]+(to[1]-from[1])*fraction;
 const point=t=>({x:320+294*Math.sin(t),y:34+28*Math.cos(t)}),height=80,corner=7,epsilon=Math.min((b-a)/8,.055);
 const number=n=>Number(n.toFixed(3)),xy=(p,dy=0)=>number(p.x)+' '+number(p.y+dy);
 const left=point(a),right=point(b),start=point(a+epsilon),finish=point(b-epsilon);
 let path='M '+xy(start);
 const points=[];
 for(let i=0;i<=24;i++){const t=a+epsilon+(b-a-2*epsilon)*i/24,p=point(t);points.push(p);if(i)path+=' L '+xy(p)}
 path+=' Q '+xy(right)+' '+xy(right,corner)+' L '+xy(right,height-corner)+' Q '+xy(right,height)+' '+xy(finish,height);
 for(let i=23;i>=0;i--)path+=' L '+xy(points[i],height);
 path+=' Q '+xy(left,height)+' '+xy(left,height-corner)+' L '+xy(left,corner)+' Q '+xy(left)+' '+xy(start)+' Z';
 const xs=[left.x,right.x,...points.map(p=>p.x)],ys=[left.y,right.y,...points.map(p=>p.y)],mid=(a+b)/2;
 return {path,cx:(Math.min(...xs)+Math.max(...xs))/2,cy:point(mid).y,width:Math.max(...xs)-Math.min(...xs),depth:Math.cos(mid),bounds:{left:Math.min(...xs),right:Math.max(...xs),top:Math.min(...ys),bottom:Math.max(...ys)+height}};
};
 for(const step of [0,.25,.5,1,2,7,-1])assert.equal(run(`townRingGeometry(${step}).path`),referenceGeometry(step).path);
 for(const total of [0,1,2,3,8,50]){
   run(`towns=Array.from({length:${total}},(_,i)=>({id:'ref'+i,city:'Pueblo '+i,score:100+i,expiresAt:Date.now()+3600000}));townCursor=0;rotateTown(false)`);
   for(let turn=0;turn<Math.max(1,total);turn++){
     assert.equal(elements['town-ring'].children.length,8);
     const ids=elements['town-ring'].children.map(c=>c.attrs['data-town-id']).filter(Boolean);
     assert.equal(new Set(ids).size,ids.length,'no cloned result on the hoop');
     assert.equal(ids.length,Math.min(total,8));
     run('rotateTown()');
   }
 }
 // The win drum is bounded, obeys mute/volume, and is cancelled by restart or leaving the result.
 const sources=[];
 class FakeAudio{
  constructor(){this.sampleRate=8000;this.currentTime=0;this.destination={};}
  resume(){return Promise.resolve()}
  createBuffer(c,n){return {getChannelData:()=>new Float32Array(n)}}
  createBufferSource(){const n={connect(){return this},disconnect(){},start(t){this.started=t},stop(){this.stopped=true}};sources.push(n);return n}
  createBiquadFilter(){return {frequency:{},Q:{},connect(){return this},disconnect(){}}}
  createGain(){return {gain:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){return this},disconnect(){}}}
 }
 context.AudioContext=FakeAudio;
 run('audio=null;muted=true;volume=.6;drumRoll()');assert.equal(sources.length,0);
 run('muted=false;volume=0;drumRoll()');assert.equal(sources.length,0);
 run('volume=.6;winningFeedback()');assert.equal(sources.length,18);assert.equal(run('endAudioNodes.length'),18);
 run('stopEndFeedback()');assert.equal(run('endAudioNodes.length'),0);assert.equal(sources.every(n=>n.stopped),true);
 run('winningFeedback();inspectBoard()');assert.equal(run('endAudioNodes.length'),0);
 run("winningFeedback();openMode('classic',true)");assert.equal(run('endAudioNodes.length'),0);
 context.atob=value=>Buffer.from(value,'base64').toString('binary');
 run("volume=.6;muted=false");
 const beforeEffects=sources.length;
 for(const name of ['pickup','place','preview','line','combo'])run(`playPieceSound('${name}')`);
 assert.equal(sources.length-beforeEffects,5,'all recorded effects play through Web Audio');
 assert.equal(new Set(sources.slice(beforeEffects).map(source=>source.buffer)).size,5);
 run("muted=true;playPieceSound('place');muted=false");
 assert.equal(sources.length-beforeEffects,5,'muting prevents recorded effects');
 // The two main buttons resume saved rounds without losing boards or scores.
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=[{shape:0,color:0},{shape:0,color:1},{shape:0,color:2}]");
 await run('place(0,0)');const calmScore=run('state.score');
 run("$('quick-towns').onclick()");assert.equal(run('mode'),'timed');assert.equal(elements['mode-name'].textContent,'Contra pueblos');
 run("$('quick-classic').onclick()");assert.equal(run('state.score'),calmScore);assert.equal(run('state.board[0]'),0);assert.equal(elements.clock.hidden,true);
 assert.equal(elements['quick-classic'].attrs['aria-pressed'],'true');
 // Optional participation and empty boards never invent an online position.
 run('communityEnabled=false');assert.match(run('roundRankHint()'),/Activa/);
 run('communityEnabled=true;towns=[];state.score=10');assert.doesNotMatch(run('roundRankHint()'),/cabeza|1.º/);
 run("towns=[{id:'a',city:'Azpeitia',score:100,expiresAt:Date.now()+3600000},{id:'b',city:'Azkoitia',score:150,expiresAt:Date.now()+3600000},{id:'c',city:'Eibar',score:150,expiresAt:Date.now()+3600000}];save('city','Azpeitia');state.score=120;showRanking()");
 assert.match(elements['rank-summary'].textContent,/Puesto 3/);assert.match(elements['rank-summary'].textContent,/51 puntos/);
 assert.equal(run("townRank('Azkoitia')"),1);assert.equal(run("townRank('Eibar')"),1,'ties share rank');
 assert.match(run('roundRankHint()'),/31 puntos/);assert.match(run('roundRankHint()'),/provisional/);
 assert.equal(elements['rank-list'].children.length,3);assert.equal(elements['rank-list'].children[2].dataset.own,'true');
 run("$('rank-close').onclick();save('lifetime-lines',0);applyTheme('bosque');showThemes()");
 assert.equal(run("get('theme','')"),'calma');assert.equal(elements['theme-options'].children[1].disabled,true);
 run("save('lifetime-lines',20);showThemes()");assert.equal(elements['theme-options'].children[1].disabled,false);assert.equal(elements['theme-options'].children[2].disabled,true);
 run("$('theme-options').children[1].onclick()");assert.equal(run("get('theme','')"),'bosque');assert.equal(run('colors[0]'),'#78b68e');
 run("$('themes-close').onclick();openMode('classic',true);state.intro=false;state.board.fill(null);for(let i=0;i<7;i++)state.board[i]=0;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,7)');assert.equal(run("get('lifetime-lines',0)"),21,'only real clears advance theme unlocks');
 run("openMode('classic',true)");assert.equal(run("get('lifetime-lines',0)"),21,'restart keeps lifetime unlocks');
 const totalBefore=run("get('lifetime-lines',0)");run("openMode('daily',true);state.intro=false;state.board.fill(null);state.score=149;state.lines=5;state.streak=3;state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 await run('place(0,0)');assert.equal(run("get('daily-done-'+day,false)"),true);assert.match(elements['daily-summary'].textContent,/completado/);
 // A completed three-minute round always has a drum, but only a new record earns the large celebration.
 const endTimers=[];context.setTimeout=callback=>{endTimers.push(callback);return endTimers.length};
 run("openMode('timed',true,123);state.over=true;state.score=10;state.priorBest=100;finishTimed(true)");
 assert.equal(run('state.personalRecord'),false);assert.equal(run('state.winCelebrated'),false);assert.equal(run('endAudioNodes.length'),18);
 endTimers.pop()();assert.equal(elements.festival.children.length,0);
 run("openMode('timed',true,123);state.over=true;state.score=101;state.priorBest=100;finishTimed(true)");
 assert.equal(run('state.personalRecord'),true);assert.equal(elements['result-title'].textContent,'¡Nuevo récord personal!');
 endTimers.pop()();assert.equal(elements.festival.children.length,0,'OS reduced-motion keeps visual celebration off');
 run('reopenResult()');assert.equal(elements['result-title'].textContent,'¡Nuevo récord personal!');assert.equal(run('endFestivalTimer'),0);
 // Predictive lines are computed without changing the real board, score or tray.
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.score=0;for(let i=0;i<8;i++){if(i!==3)state.board[24+i]=1;if(i!==3)state.board[i*8+3]=2;}state.tray=Array.from({length:3},()=>({shape:0,color:0}));render()");
 const beforePreview=run('JSON.stringify(state)');
 assert.equal(run('placementPreview(state.tray[0],3,3).lines.length'),2);
 assert.equal(run('placementPreview(state.tray[0],3,3).filled.size'),15);
 assert.equal(run('placementPreview(state.tray[0],2,3).lines.length'),0,'occupied spot has no promise of a clear');
 const touchButton=elements.tray.children[0];touchButton.setPointerCapture=()=>{};touchButton.releasePointerCapture=()=>{};
 const ev=(x,y)=>({target:{closest:()=>touchButton},pointerId:11,pointerType:'touch',button:0,clientX:x,clientY:y,preventDefault(){}});
 elements.tray.onpointerdown(ev(149,700));assert.equal(run('Boolean(drag.ghost)'),true,'piece lifts at press, without waiting for movement');
 assert.equal(run('drag.ghost.style.top'),'556px','full-size shape floats above the fingertip');
 elements.tray.onpointermove(ev(149,273));assert.equal(elements['preview-lines'].children.length,2);
 assert.equal(elements.board.children.filter(c=>c.classes.has('line-ready')).length,15);
 assert.equal(run('JSON.stringify(state)'),beforePreview,'light preview awards no points and consumes no piece');
 elements.tray.onpointercancel({pointerId:11});assert.equal(run('drag'),null);assert.equal(elements['preview-lines'].children.length,0);
 assert.equal(elements.board.children.some(c=>c.classes.has('line-ready')),false);
 assert.equal(run('JSON.stringify(state)'),beforePreview);
 elements.tray.onpointerdown(ev(149,700));elements.tray.onpointerup(ev(149,700));assert.equal(run('selected'),0,'tap then tap remains usable');assert.equal(run('state.score'),0);
 elements.tray.onpointerdown(ev(149,700));elements.tray.onpointermove(ev(-200,-200));elements.tray.onpointerup(ev(-200,-200));
 assert.equal(run('state.score'),0);assert.equal(run('state.tray[0]!==null'),true,'invalid release returns the piece');
 elements.tray.onpointerdown(ev(149,700));elements.tray.onpointermove(ev(149,273));elements.tray.onpointerup(ev(149,273));
 assert.equal(run('state.lines'),2);assert.equal(run('state.tray[0]'),null);assert.equal(elements['preview-lines'].children.length,0);
 // Touching the text row below a piece resolves its own column, never a neighbour.
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=Array.from({length:3},()=>({shape:0,color:0}));render()");
 elements.tray.getBoundingClientRect=()=>({left:0,top:600,width:300,height:200});
 elements['town-carousel'].getBoundingClientRect=()=>({left:0,top:900,width:300,height:150});
 elements.tray.children.forEach((b,i)=>{b.getBoundingClientRect=()=>({left:i*100,top:600,width:100,height:200});b.setPointerCapture=()=>{};b.releasePointerCapture=()=>{}});
 for(const [x,slot] of [[50,0],[150,1],[250,2]]){
   const event={target:elements.status,pointerId:51,pointerType:'touch',button:0,clientX:x,clientY:880,preventDefault(){}};
   elements.status.closest=()=>null;
   elements.game.onpointerdown(event);assert.equal(run('drag.slot'),slot);assert.equal(run('Boolean(drag.ghost)'),true);
   elements.game.onpointercancel(event);assert.equal(run('drag'),null);
 }
 assert.equal(run('lowerPickupSlot(250,900)'),-1,'the town carousel stays outside the pickup region');
 assert.equal(run('lowerPickupSlot(250,599)'),-1,'the board is not a pickup area');
 run('state.tray[1]=null;render()');elements.tray.children.forEach((b,i)=>{b.getBoundingClientRect=()=>({left:i*100,top:600,width:100,height:200});});
 assert.equal(run('lowerPickupSlot(150,880)'),-1,'an empty column does not steal its neighbour');
 // Only the current highest-scoring town has drums, and one arrival does not restart effects every refresh.
 context.matchMedia=()=>({matches:false});
 run("visualEffects=true;towns=[{id:'win',city:'Salamanca',score:900,expiresAt:Date.now()+3600000},{id:'other',city:'Azpeitia',score:800,expiresAt:Date.now()+3600000}];townCursor=0;rotateTown(false)");
 assert.equal(elements['town-drum-left'].hidden,false);assert.equal(elements['town-drum-right'].hidden,false);
 assert.equal(elements['town-fireworks'].children.length,24);assert.match(elements['town-direction'].textContent,/Enhorabuena/);
 run('rotateTown(false)');assert.equal(elements['town-fireworks'].children.length,24,'same arrival does not accumulate sparks');
 run('townCursor=1;rotateTown(false)');assert.equal(elements['town-drum-left'].hidden,true);assert.equal(elements['town-fireworks'].children.length,0);
 run('townCursor=0;rotateTown(false)');assert.equal(elements['town-drum-left'].hidden,false);assert.equal(elements['town-fireworks'].children.length,0,'cooldown limits repeat bursts');
 run("towns[1].score=1000;rotateTown(false)");assert.equal(elements['town-drum-left'].hidden,true,'leadership follows the actual best mark');
 context.matchMedia=()=>({matches:true});run('townCursor=1;rotateTown(false)');assert.equal(elements['town-drum-left'].hidden,false);assert.equal(elements['town-fireworks'].children.length,0,'reduced motion leaves only static drums');
 now+=3600000;run('rotateTown(false)');assert.equal(elements['town-drum-left'].hidden,true);assert.equal(elements['town-direction'].textContent,'⤳');
 // The reference-inspired classic finish is visual only: one tone, stored colors untouched.
 run("openMode('classic',true);save('lifetime-lines',60);applyTheme('calma')");
 assert.equal(run('new Set([0,1,2,3,4].map(tileColor)).size'),1);
 assert.equal(run('tileColor(0)'), '#dc78a0');
 run("applyTheme('bosque')");assert.equal(run('tileColor(4)'),'#78b68e');
 run("openMode('timed',true)");assert.equal(run('new Set([0,1,2,3,4].map(tileColor)).size'),1);
 // Drums belong to the centre card; reserved insets keep them inside its actual projected face.
 const frontMarkup=html.match(/<div id="town-front"[\s\S]*?<\/div>/)[0];
 assert.match(frontMarkup,/id="town-drum-left"/);assert.match(frontMarkup,/id="town-drum-right"/);
 for(const width of [280,345,460]){
   const face=run('townRingGeometry(0).bounds');
   const left=width*.273+1,right=width*(.273+.454)-1;
   assert.ok(left>=face.left/640*width);assert.ok(right<=face.right/640*width);
   assert.ok(right-left>60,'both 30px drum drawings fit');
 }
 // Praise cycles through every phrase in its group and never repeats immediately.
 for(const kind of ['single','double','massive','clear']){
   run(`delete praiseBags['${kind}']`);const words=[];const size=run(`praiseWords['${kind}'].length`);
   for(let i=0;i<size;i++)words.push(run(`nextPraise('${kind}')`));
   assert.equal(new Set(words).size,size);const last=words[words.length-1];assert.notEqual(run(`nextPraise('${kind}')`),last);
 }
 run("openMode('classic',true);state.score=120;state.combo=3;state.board[0]=1");
 const originalSeed=run('state.seed');run('lineFeedback(2,4)');assert.match(elements['combo-label'].textContent,/Combo ×3/);assert.match(elements['combo-points'].textContent,/2 líneas/);assert.equal(run('state.seed'),originalSeed,'praise does not alter future pieces');
 context.matchMedia=()=>({matches:false});run('visualEffects=true');
 run("openMode('classic',true);state.intro=false;state.board.fill(null);state.tray=Array.from({length:3},()=>({shape:0,color:0}))");
 for(let i=0;i<3;i++)await run(`place(${i},${i})`);
 assert.equal(elements['clear-effects'].children[0].textContent,'👍');
 await run('state.tray[0]={shape:0,color:0};place(0,3)');assert.equal(elements['clear-effects'].children.at(-1).className,'cell-reward fruit');
 assert.equal(run('state.score'),4,'fruit and its animation do not award points');
 const firstFruit=elements['clear-effects'].children.at(-1).textContent;
 run('state.placementStreak=state.nextFruit-1;placementReward(4)');
 assert.notEqual(elements['clear-effects'].children.at(-1).textContent,firstFruit);
 run("openMode('timed',true);state.over=true;state.score=100;state.priorBest=50;finishTimed(true)");
 endTimers.pop()();assert.equal(elements['result-lion'].hidden,false);
 run("inspectBoard();openMode('classic',true)");assert.equal(elements['result-lion'].hidden,true);
 assert.equal(run("tileColor(0)"),run("tileColor(4)"));
 run("openMode('timed',true)");assert.equal(run("tileColor(0)"),run("tileColor(4)"));
 run("openMode('classic',true);state.board=['......##','..#...##','.######.','.######.','#####.##','####..##','#####...','.....###'].join('').split('').map(c=>c==='#'?0:null);state.tray=[{shape:16,color:0},null,{shape:14,color:0}]");
 assert.equal(run('canContinue()'),false,'neither remaining piece fits the pictured board');
 run('state.board[7]=state.board[15]=state.board[39]=null');
 assert.equal(run('canContinue()'),true,'a complete five-cell column keeps the game going');
 const savedState=run('JSON.stringify(state)');
 for(const [lineCount,cellCount,expectedParticles] of [[1,8,8],[2,15,30],[3,22,66],[8,64,128]]){
   const before= context.document.body.children.length;
   run(`celebrate(Array.from({length:${cellCount}},(_,i)=>[i,0]),${lineCount})`);
   assert.equal(context.document.body.children.length-before,expectedParticles);
   assert.equal(elements['clear-effects'].children.filter(e=>e.className==='clear-shockwave').length,lineCount===1?0:Math.min(3,lineCount));
   assert.equal(run('JSON.stringify(state)'),savedState,'extra bursts do not invent points');
 }
 context.matchMedia=()=>({matches:true});const particleTotal=context.document.body.children.length;run('celebrate([[0,0]],3)');assert.equal(context.document.body.children.length,particleTotal);
 console.log('PASS: volume, easy pieces, timer modes, 3-min finish, city publishing, offline fallback, 50-name circular rotation, interrupted animation, manual pause and single-town display, independent expiry, raised drag, invalid drops, elapsed clocks, privacy opt-out, instant restart, classic large pieces, calm play, row/column clears, combo grace and haptic preference, final-board navigation, resumed game-over, visual-effect cleanup and OS motion preference');
})().catch(e=>{console.error(e);process.exit(1)});
